/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.6.28-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: localhost    Database: testlink
-- ------------------------------------------------------
-- Server version	10.6.28-MariaDB-ubu2204

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `assignment_status`
--

DROP TABLE IF EXISTS `assignment_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `assignment_status` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `description` varchar(100) NOT NULL DEFAULT 'unknown',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assignment_status`
--

LOCK TABLES `assignment_status` WRITE;
/*!40000 ALTER TABLE `assignment_status` DISABLE KEYS */;
INSERT INTO `assignment_status` VALUES (1,'open'),(2,'closed'),(3,'completed'),(4,'todo_urgent'),(5,'todo');
/*!40000 ALTER TABLE `assignment_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assignment_types`
--

DROP TABLE IF EXISTS `assignment_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `assignment_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fk_table` varchar(30) DEFAULT '',
  `description` varchar(100) NOT NULL DEFAULT 'unknown',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assignment_types`
--

LOCK TABLES `assignment_types` WRITE;
/*!40000 ALTER TABLE `assignment_types` DISABLE KEYS */;
INSERT INTO `assignment_types` VALUES (1,'testplan_tcversions','testcase_execution'),(2,'tcversions','testcase_review');
/*!40000 ALTER TABLE `assignment_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attachments`
--

DROP TABLE IF EXISTS `attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `attachments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fk_id` int(10) unsigned NOT NULL DEFAULT 0,
  `fk_table` varchar(250) DEFAULT '',
  `title` varchar(250) DEFAULT '',
  `description` varchar(250) DEFAULT '',
  `file_name` varchar(250) NOT NULL DEFAULT '',
  `file_path` varchar(250) DEFAULT '',
  `file_size` int(11) NOT NULL DEFAULT 0,
  `file_type` varchar(250) NOT NULL DEFAULT '',
  `date_added` timestamp NOT NULL DEFAULT current_timestamp(),
  `content` longblob DEFAULT NULL,
  `compression_type` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `attachments_idx1` (`fk_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attachments`
--

LOCK TABLES `attachments` WRITE;
/*!40000 ALTER TABLE `attachments` DISABLE KEYS */;
/*!40000 ALTER TABLE `attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `baseline_l1l2_context`
--

DROP TABLE IF EXISTS `baseline_l1l2_context`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `baseline_l1l2_context` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `testplan_id` int(10) unsigned NOT NULL DEFAULT 0,
  `platform_id` int(10) unsigned NOT NULL DEFAULT 0,
  `begin_exec_ts` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `end_exec_ts` timestamp NOT NULL DEFAULT current_timestamp(),
  `creation_ts` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `udx1_context` (`testplan_id`,`platform_id`,`creation_ts`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `baseline_l1l2_context`
--

LOCK TABLES `baseline_l1l2_context` WRITE;
/*!40000 ALTER TABLE `baseline_l1l2_context` DISABLE KEYS */;
/*!40000 ALTER TABLE `baseline_l1l2_context` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `baseline_l1l2_details`
--

DROP TABLE IF EXISTS `baseline_l1l2_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `baseline_l1l2_details` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `context_id` int(10) unsigned NOT NULL,
  `top_tsuite_id` int(10) unsigned NOT NULL DEFAULT 0,
  `child_tsuite_id` int(10) unsigned NOT NULL DEFAULT 0,
  `status` char(1) DEFAULT NULL,
  `qty` int(10) unsigned NOT NULL DEFAULT 0,
  `total_tc` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `udx1_details` (`context_id`,`top_tsuite_id`,`child_tsuite_id`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `baseline_l1l2_details`
--

LOCK TABLES `baseline_l1l2_details` WRITE;
/*!40000 ALTER TABLE `baseline_l1l2_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `baseline_l1l2_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `builds`
--

DROP TABLE IF EXISTS `builds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `builds` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `testplan_id` int(10) unsigned NOT NULL DEFAULT 0,
  `name` varchar(100) NOT NULL DEFAULT 'undefined',
  `notes` text DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `is_open` tinyint(1) NOT NULL DEFAULT 1,
  `author_id` int(10) unsigned DEFAULT NULL,
  `creation_ts` timestamp NOT NULL DEFAULT current_timestamp(),
  `release_date` date DEFAULT NULL,
  `closed_on_date` date DEFAULT NULL,
  `commit_id` varchar(64) DEFAULT NULL,
  `tag` varchar(64) DEFAULT NULL,
  `branch` varchar(64) DEFAULT NULL,
  `release_candidate` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`testplan_id`,`name`),
  KEY `testplan_id` (`testplan_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Available builds';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `builds`
--

LOCK TABLES `builds` WRITE;
/*!40000 ALTER TABLE `builds` DISABLE KEYS */;
INSERT INTO `builds` VALUES (1,266,'UniShare main@b124314','<p>github.com/Seganation/unishare main branch, commit b124314 (2026-05-03).</p>',1,1,NULL,'2026-10-26 15:39:04',NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `builds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cfield_build_design_values`
--

DROP TABLE IF EXISTS `cfield_build_design_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cfield_build_design_values` (
  `field_id` int(10) NOT NULL DEFAULT 0,
  `node_id` int(10) NOT NULL DEFAULT 0,
  `value` varchar(4000) NOT NULL DEFAULT '',
  PRIMARY KEY (`field_id`,`node_id`),
  KEY `idx_cfield_build_design_values` (`node_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cfield_build_design_values`
--

LOCK TABLES `cfield_build_design_values` WRITE;
/*!40000 ALTER TABLE `cfield_build_design_values` DISABLE KEYS */;
/*!40000 ALTER TABLE `cfield_build_design_values` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cfield_design_values`
--

DROP TABLE IF EXISTS `cfield_design_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cfield_design_values` (
  `field_id` int(10) NOT NULL DEFAULT 0,
  `node_id` int(10) NOT NULL DEFAULT 0,
  `value` varchar(4000) NOT NULL DEFAULT '',
  PRIMARY KEY (`field_id`,`node_id`),
  KEY `idx_cfield_design_values` (`node_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cfield_design_values`
--

LOCK TABLES `cfield_design_values` WRITE;
/*!40000 ALTER TABLE `cfield_design_values` DISABLE KEYS */;
/*!40000 ALTER TABLE `cfield_design_values` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cfield_execution_values`
--

DROP TABLE IF EXISTS `cfield_execution_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cfield_execution_values` (
  `field_id` int(10) NOT NULL DEFAULT 0,
  `execution_id` int(10) NOT NULL DEFAULT 0,
  `testplan_id` int(10) NOT NULL DEFAULT 0,
  `tcversion_id` int(10) NOT NULL DEFAULT 0,
  `value` varchar(4000) NOT NULL DEFAULT '',
  PRIMARY KEY (`field_id`,`execution_id`,`testplan_id`,`tcversion_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cfield_execution_values`
--

LOCK TABLES `cfield_execution_values` WRITE;
/*!40000 ALTER TABLE `cfield_execution_values` DISABLE KEYS */;
/*!40000 ALTER TABLE `cfield_execution_values` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cfield_node_types`
--

DROP TABLE IF EXISTS `cfield_node_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cfield_node_types` (
  `field_id` int(10) NOT NULL DEFAULT 0,
  `node_type_id` int(10) NOT NULL DEFAULT 0,
  PRIMARY KEY (`field_id`,`node_type_id`),
  KEY `idx_custom_fields_assign` (`node_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cfield_node_types`
--

LOCK TABLES `cfield_node_types` WRITE;
/*!40000 ALTER TABLE `cfield_node_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `cfield_node_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cfield_testplan_design_values`
--

DROP TABLE IF EXISTS `cfield_testplan_design_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cfield_testplan_design_values` (
  `field_id` int(10) NOT NULL DEFAULT 0,
  `link_id` int(10) NOT NULL DEFAULT 0 COMMENT 'point to testplan_tcversion id',
  `value` varchar(4000) NOT NULL DEFAULT '',
  PRIMARY KEY (`field_id`,`link_id`),
  KEY `idx_cfield_tplan_design_val` (`link_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cfield_testplan_design_values`
--

LOCK TABLES `cfield_testplan_design_values` WRITE;
/*!40000 ALTER TABLE `cfield_testplan_design_values` DISABLE KEYS */;
/*!40000 ALTER TABLE `cfield_testplan_design_values` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cfield_testprojects`
--

DROP TABLE IF EXISTS `cfield_testprojects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cfield_testprojects` (
  `field_id` int(10) unsigned NOT NULL DEFAULT 0,
  `testproject_id` int(10) unsigned NOT NULL DEFAULT 0,
  `display_order` smallint(5) unsigned NOT NULL DEFAULT 1,
  `location` smallint(5) unsigned NOT NULL DEFAULT 1,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `required` tinyint(1) NOT NULL DEFAULT 0,
  `required_on_design` tinyint(1) NOT NULL DEFAULT 0,
  `required_on_execution` tinyint(1) NOT NULL DEFAULT 0,
  `monitorable` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`field_id`,`testproject_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cfield_testprojects`
--

LOCK TABLES `cfield_testprojects` WRITE;
/*!40000 ALTER TABLE `cfield_testprojects` DISABLE KEYS */;
/*!40000 ALTER TABLE `cfield_testprojects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `codetrackers`
--

DROP TABLE IF EXISTS `codetrackers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `codetrackers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `type` int(10) DEFAULT 0,
  `cfg` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `codetrackers_uidx1` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `codetrackers`
--

LOCK TABLES `codetrackers` WRITE;
/*!40000 ALTER TABLE `codetrackers` DISABLE KEYS */;
/*!40000 ALTER TABLE `codetrackers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_fields`
--

DROP TABLE IF EXISTS `custom_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `custom_fields` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL DEFAULT '',
  `label` varchar(64) NOT NULL DEFAULT '' COMMENT 'label to display on user interface',
  `type` smallint(6) NOT NULL DEFAULT 0,
  `possible_values` varchar(4000) NOT NULL DEFAULT '',
  `default_value` varchar(4000) NOT NULL DEFAULT '',
  `valid_regexp` varchar(255) NOT NULL DEFAULT '',
  `length_min` int(10) NOT NULL DEFAULT 0,
  `length_max` int(10) NOT NULL DEFAULT 0,
  `show_on_design` tinyint(3) unsigned NOT NULL DEFAULT 1 COMMENT '1=> show it during specification design',
  `enable_on_design` tinyint(3) unsigned NOT NULL DEFAULT 1 COMMENT '1=> user can write/manage it during specification design',
  `show_on_execution` tinyint(3) unsigned NOT NULL DEFAULT 0 COMMENT '1=> show it during test case execution',
  `enable_on_execution` tinyint(3) unsigned NOT NULL DEFAULT 0 COMMENT '1=> user can write/manage it during test case execution',
  `show_on_testplan_design` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `enable_on_testplan_design` tinyint(3) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_custom_fields_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_fields`
--

LOCK TABLES `custom_fields` WRITE;
/*!40000 ALTER TABLE `custom_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `custom_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `db_version`
--

DROP TABLE IF EXISTS `db_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `db_version` (
  `version` varchar(50) NOT NULL DEFAULT 'unknown',
  `upgrade_ts` timestamp NOT NULL DEFAULT current_timestamp(),
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `db_version`
--

LOCK TABLES `db_version` WRITE;
/*!40000 ALTER TABLE `db_version` DISABLE KEYS */;
INSERT INTO `db_version` VALUES ('DB 1.9.20','2026-10-26 15:26:05','TestLink 1.9.20 Raijin');
/*!40000 ALTER TABLE `db_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `events`
--

DROP TABLE IF EXISTS `events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `events` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `transaction_id` int(10) unsigned NOT NULL DEFAULT 0,
  `log_level` smallint(5) unsigned NOT NULL DEFAULT 0,
  `source` varchar(45) DEFAULT NULL,
  `description` text NOT NULL,
  `fired_at` int(10) unsigned NOT NULL DEFAULT 0,
  `activity` varchar(45) DEFAULT NULL,
  `object_id` int(10) unsigned DEFAULT NULL,
  `object_type` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `transaction_id` (`transaction_id`),
  KEY `fired_at` (`fired_at`)
) ENGINE=InnoDB AUTO_INCREMENT=361 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `events`
--

LOCK TABLES `events` WRITE;
/*!40000 ALTER TABLE `events` DISABLE KEYS */;
INSERT INTO `events` VALUES (1,1,16,'API-XMLRPC','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:25:\"audit_testproject_created\";s:6:\"params\";a:1:{i:0;s:8:\"UniShare\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029139,'CREATE',1,'testprojects'),(2,1,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: itsOK - in /var/www/html/lib/api/xmlrpc/v1/xmlrpc.class.php - Line 2200',1793029139,'PHP',0,NULL),(3,2,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:35:\"audit_users_roles_added_testproject\";s:6:\"params\";a:3:{i:0;s:4:\"rawa\";i:1;s:8:\"UniShare\";i:2;s:13:\"senior tester\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029139,'ASSIGN',1,'testprojects'),(4,3,16,'GUI - Test Project ID : 1','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:21:\"audit_login_succeeded\";s:6:\"params\";a:2:{i:0;s:5:\"admin\";i:1;s:12:\"192.168.65.1\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029139,'LOGIN',1,'users'),(5,4,32,'GUI - Test Project ID : 1','string \'req_title_lenght_exceeded\' is not localized for locale \'en_GB\' ',1793029139,'LOCALIZATION',0,NULL),(6,4,32,'GUI - Test Project ID : 1','string \'req_docid_lenght_exceeded\' is not localized for locale \'en_GB\' ',1793029139,'LOCALIZATION',0,NULL),(7,4,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: tlCfg - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(8,4,2,'GUI - Test Project ID : 1','E_NOTICE\nTrying to get property \'charset\' of non-object - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(9,4,2,'GUI - Test Project ID : 1','E_WARNING\nmb_strlen(): Unknown encoding &quot;&quot; - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(10,4,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: tlCfg - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(11,4,2,'GUI - Test Project ID : 1','E_NOTICE\nTrying to get property \'charset\' of non-object - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(12,4,2,'GUI - Test Project ID : 1','E_WARNING\nmb_strlen(): Unknown encoding &quot;&quot; - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(13,4,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: tlCfg - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(14,4,2,'GUI - Test Project ID : 1','E_NOTICE\nTrying to get property \'charset\' of non-object - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(15,4,2,'GUI - Test Project ID : 1','E_WARNING\nmb_strlen(): Unknown encoding &quot;&quot; - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(16,4,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: tlCfg - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(17,4,2,'GUI - Test Project ID : 1','E_NOTICE\nTrying to get property \'charset\' of non-object - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(18,4,2,'GUI - Test Project ID : 1','E_WARNING\nmb_strlen(): Unknown encoding &quot;&quot; - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(19,4,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: tlCfg - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(20,4,2,'GUI - Test Project ID : 1','E_NOTICE\nTrying to get property \'charset\' of non-object - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(21,4,2,'GUI - Test Project ID : 1','E_WARNING\nmb_strlen(): Unknown encoding &quot;&quot; - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(22,4,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: tlCfg - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(23,4,2,'GUI - Test Project ID : 1','E_NOTICE\nTrying to get property \'charset\' of non-object - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(24,4,2,'GUI - Test Project ID : 1','E_WARNING\nmb_strlen(): Unknown encoding &quot;&quot; - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(25,4,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: tlCfg - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(26,4,2,'GUI - Test Project ID : 1','E_NOTICE\nTrying to get property \'charset\' of non-object - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(27,4,2,'GUI - Test Project ID : 1','E_WARNING\nmb_strlen(): Unknown encoding &quot;&quot; - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(28,4,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: tlCfg - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(29,4,2,'GUI - Test Project ID : 1','E_NOTICE\nTrying to get property \'charset\' of non-object - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(30,4,2,'GUI - Test Project ID : 1','E_WARNING\nmb_strlen(): Unknown encoding &quot;&quot; - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(31,4,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: tlCfg - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(32,4,2,'GUI - Test Project ID : 1','E_NOTICE\nTrying to get property \'charset\' of non-object - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(33,4,2,'GUI - Test Project ID : 1','E_WARNING\nmb_strlen(): Unknown encoding &quot;&quot; - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(34,4,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: tlCfg - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(35,4,2,'GUI - Test Project ID : 1','E_NOTICE\nTrying to get property \'charset\' of non-object - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(36,4,2,'GUI - Test Project ID : 1','E_WARNING\nmb_strlen(): Unknown encoding &quot;&quot; - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(37,4,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: tlCfg - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(38,4,2,'GUI - Test Project ID : 1','E_NOTICE\nTrying to get property \'charset\' of non-object - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(39,4,2,'GUI - Test Project ID : 1','E_WARNING\nmb_strlen(): Unknown encoding &quot;&quot; - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(40,4,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: tlCfg - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(41,4,2,'GUI - Test Project ID : 1','E_NOTICE\nTrying to get property \'charset\' of non-object - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(42,4,2,'GUI - Test Project ID : 1','E_WARNING\nmb_strlen(): Unknown encoding &quot;&quot; - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(43,4,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: tlCfg - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(44,4,2,'GUI - Test Project ID : 1','E_NOTICE\nTrying to get property \'charset\' of non-object - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(45,4,2,'GUI - Test Project ID : 1','E_WARNING\nmb_strlen(): Unknown encoding &quot;&quot; - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(46,4,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: tlCfg - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(47,4,2,'GUI - Test Project ID : 1','E_NOTICE\nTrying to get property \'charset\' of non-object - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(48,4,2,'GUI - Test Project ID : 1','E_WARNING\nmb_strlen(): Unknown encoding &quot;&quot; - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(49,4,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: tlCfg - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(50,4,2,'GUI - Test Project ID : 1','E_NOTICE\nTrying to get property \'charset\' of non-object - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(51,4,2,'GUI - Test Project ID : 1','E_WARNING\nmb_strlen(): Unknown encoding &quot;&quot; - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(52,4,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: tlCfg - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(53,4,2,'GUI - Test Project ID : 1','E_NOTICE\nTrying to get property \'charset\' of non-object - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(54,4,2,'GUI - Test Project ID : 1','E_WARNING\nmb_strlen(): Unknown encoding &quot;&quot; - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(55,4,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: tlCfg - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(56,4,2,'GUI - Test Project ID : 1','E_NOTICE\nTrying to get property \'charset\' of non-object - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(57,4,2,'GUI - Test Project ID : 1','E_WARNING\nmb_strlen(): Unknown encoding &quot;&quot; - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(58,4,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: tlCfg - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(59,4,2,'GUI - Test Project ID : 1','E_NOTICE\nTrying to get property \'charset\' of non-object - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(60,4,2,'GUI - Test Project ID : 1','E_WARNING\nmb_strlen(): Unknown encoding &quot;&quot; - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(61,4,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: tlCfg - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(62,4,2,'GUI - Test Project ID : 1','E_NOTICE\nTrying to get property \'charset\' of non-object - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(63,4,2,'GUI - Test Project ID : 1','E_WARNING\nmb_strlen(): Unknown encoding &quot;&quot; - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(64,4,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: tlCfg - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(65,4,2,'GUI - Test Project ID : 1','E_NOTICE\nTrying to get property \'charset\' of non-object - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(66,4,2,'GUI - Test Project ID : 1','E_WARNING\nmb_strlen(): Unknown encoding &quot;&quot; - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(67,4,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: tlCfg - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(68,4,2,'GUI - Test Project ID : 1','E_NOTICE\nTrying to get property \'charset\' of non-object - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(69,4,2,'GUI - Test Project ID : 1','E_WARNING\nmb_strlen(): Unknown encoding &quot;&quot; - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(70,4,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: tlCfg - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(71,4,2,'GUI - Test Project ID : 1','E_NOTICE\nTrying to get property \'charset\' of non-object - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(72,4,2,'GUI - Test Project ID : 1','E_WARNING\nmb_strlen(): Unknown encoding &quot;&quot; - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(73,4,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: tlCfg - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(74,4,2,'GUI - Test Project ID : 1','E_NOTICE\nTrying to get property \'charset\' of non-object - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(75,4,2,'GUI - Test Project ID : 1','E_WARNING\nmb_strlen(): Unknown encoding &quot;&quot; - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(76,4,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: tlCfg - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(77,4,2,'GUI - Test Project ID : 1','E_NOTICE\nTrying to get property \'charset\' of non-object - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(78,4,2,'GUI - Test Project ID : 1','E_WARNING\nmb_strlen(): Unknown encoding &quot;&quot; - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(79,4,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: tlCfg - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(80,4,2,'GUI - Test Project ID : 1','E_NOTICE\nTrying to get property \'charset\' of non-object - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(81,4,2,'GUI - Test Project ID : 1','E_WARNING\nmb_strlen(): Unknown encoding &quot;&quot; - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(82,4,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: tlCfg - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(83,4,2,'GUI - Test Project ID : 1','E_NOTICE\nTrying to get property \'charset\' of non-object - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(84,4,2,'GUI - Test Project ID : 1','E_WARNING\nmb_strlen(): Unknown encoding &quot;&quot; - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(85,4,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: tlCfg - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(86,4,2,'GUI - Test Project ID : 1','E_NOTICE\nTrying to get property \'charset\' of non-object - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(87,4,2,'GUI - Test Project ID : 1','E_WARNING\nmb_strlen(): Unknown encoding &quot;&quot; - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(88,4,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: tlCfg - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(89,4,2,'GUI - Test Project ID : 1','E_NOTICE\nTrying to get property \'charset\' of non-object - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(90,4,2,'GUI - Test Project ID : 1','E_WARNING\nmb_strlen(): Unknown encoding &quot;&quot; - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(91,4,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: tlCfg - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(92,4,2,'GUI - Test Project ID : 1','E_NOTICE\nTrying to get property \'charset\' of non-object - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(93,4,2,'GUI - Test Project ID : 1','E_WARNING\nmb_strlen(): Unknown encoding &quot;&quot; - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(94,4,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: tlCfg - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(95,4,2,'GUI - Test Project ID : 1','E_NOTICE\nTrying to get property \'charset\' of non-object - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(96,4,2,'GUI - Test Project ID : 1','E_WARNING\nmb_strlen(): Unknown encoding &quot;&quot; - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(97,4,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: tlCfg - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(98,4,2,'GUI - Test Project ID : 1','E_NOTICE\nTrying to get property \'charset\' of non-object - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(99,4,2,'GUI - Test Project ID : 1','E_WARNING\nmb_strlen(): Unknown encoding &quot;&quot; - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(100,4,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: tlCfg - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(101,4,2,'GUI - Test Project ID : 1','E_NOTICE\nTrying to get property \'charset\' of non-object - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(102,4,2,'GUI - Test Project ID : 1','E_WARNING\nmb_strlen(): Unknown encoding &quot;&quot; - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(103,4,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: tlCfg - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(104,4,2,'GUI - Test Project ID : 1','E_NOTICE\nTrying to get property \'charset\' of non-object - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(105,4,2,'GUI - Test Project ID : 1','E_WARNING\nmb_strlen(): Unknown encoding &quot;&quot; - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(106,4,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: tlCfg - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(107,4,2,'GUI - Test Project ID : 1','E_NOTICE\nTrying to get property \'charset\' of non-object - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(108,4,2,'GUI - Test Project ID : 1','E_WARNING\nmb_strlen(): Unknown encoding &quot;&quot; - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(109,4,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: tlCfg - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(110,4,2,'GUI - Test Project ID : 1','E_NOTICE\nTrying to get property \'charset\' of non-object - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(111,4,2,'GUI - Test Project ID : 1','E_WARNING\nmb_strlen(): Unknown encoding &quot;&quot; - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(112,4,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: tlCfg - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(113,4,2,'GUI - Test Project ID : 1','E_NOTICE\nTrying to get property \'charset\' of non-object - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(114,4,2,'GUI - Test Project ID : 1','E_WARNING\nmb_strlen(): Unknown encoding &quot;&quot; - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(115,4,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: tlCfg - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(116,4,2,'GUI - Test Project ID : 1','E_NOTICE\nTrying to get property \'charset\' of non-object - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(117,4,2,'GUI - Test Project ID : 1','E_WARNING\nmb_strlen(): Unknown encoding &quot;&quot; - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(118,4,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: tlCfg - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(119,4,2,'GUI - Test Project ID : 1','E_NOTICE\nTrying to get property \'charset\' of non-object - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(120,4,2,'GUI - Test Project ID : 1','E_WARNING\nmb_strlen(): Unknown encoding &quot;&quot; - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(121,4,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: tlCfg - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(122,4,2,'GUI - Test Project ID : 1','E_NOTICE\nTrying to get property \'charset\' of non-object - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(123,4,2,'GUI - Test Project ID : 1','E_WARNING\nmb_strlen(): Unknown encoding &quot;&quot; - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(124,4,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: tlCfg - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(125,4,2,'GUI - Test Project ID : 1','E_NOTICE\nTrying to get property \'charset\' of non-object - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(126,4,2,'GUI - Test Project ID : 1','E_WARNING\nmb_strlen(): Unknown encoding &quot;&quot; - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(127,4,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: tlCfg - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(128,4,2,'GUI - Test Project ID : 1','E_NOTICE\nTrying to get property \'charset\' of non-object - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(129,4,2,'GUI - Test Project ID : 1','E_WARNING\nmb_strlen(): Unknown encoding &quot;&quot; - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(130,4,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: tlCfg - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(131,4,2,'GUI - Test Project ID : 1','E_NOTICE\nTrying to get property \'charset\' of non-object - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(132,4,2,'GUI - Test Project ID : 1','E_WARNING\nmb_strlen(): Unknown encoding &quot;&quot; - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(133,4,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: tlCfg - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(134,4,2,'GUI - Test Project ID : 1','E_NOTICE\nTrying to get property \'charset\' of non-object - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(135,4,2,'GUI - Test Project ID : 1','E_WARNING\nmb_strlen(): Unknown encoding &quot;&quot; - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(136,4,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: tlCfg - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(137,4,2,'GUI - Test Project ID : 1','E_NOTICE\nTrying to get property \'charset\' of non-object - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(138,4,2,'GUI - Test Project ID : 1','E_WARNING\nmb_strlen(): Unknown encoding &quot;&quot; - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(139,4,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: tlCfg - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(140,4,2,'GUI - Test Project ID : 1','E_NOTICE\nTrying to get property \'charset\' of non-object - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(141,4,2,'GUI - Test Project ID : 1','E_WARNING\nmb_strlen(): Unknown encoding &quot;&quot; - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(142,4,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: tlCfg - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(143,4,2,'GUI - Test Project ID : 1','E_NOTICE\nTrying to get property \'charset\' of non-object - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(144,4,2,'GUI - Test Project ID : 1','E_WARNING\nmb_strlen(): Unknown encoding &quot;&quot; - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(145,4,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: tlCfg - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(146,4,2,'GUI - Test Project ID : 1','E_NOTICE\nTrying to get property \'charset\' of non-object - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(147,4,2,'GUI - Test Project ID : 1','E_WARNING\nmb_strlen(): Unknown encoding &quot;&quot; - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(148,4,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: tlCfg - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(149,4,2,'GUI - Test Project ID : 1','E_NOTICE\nTrying to get property \'charset\' of non-object - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(150,4,2,'GUI - Test Project ID : 1','E_WARNING\nmb_strlen(): Unknown encoding &quot;&quot; - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(151,4,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: tlCfg - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(152,4,2,'GUI - Test Project ID : 1','E_NOTICE\nTrying to get property \'charset\' of non-object - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(153,4,2,'GUI - Test Project ID : 1','E_WARNING\nmb_strlen(): Unknown encoding &quot;&quot; - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(154,4,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: tlCfg - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(155,4,2,'GUI - Test Project ID : 1','E_NOTICE\nTrying to get property \'charset\' of non-object - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(156,4,2,'GUI - Test Project ID : 1','E_WARNING\nmb_strlen(): Unknown encoding &quot;&quot; - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(157,4,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: tlCfg - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(158,4,2,'GUI - Test Project ID : 1','E_NOTICE\nTrying to get property \'charset\' of non-object - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(159,4,2,'GUI - Test Project ID : 1','E_WARNING\nmb_strlen(): Unknown encoding &quot;&quot; - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(160,4,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: tlCfg - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(161,4,2,'GUI - Test Project ID : 1','E_NOTICE\nTrying to get property \'charset\' of non-object - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(162,4,2,'GUI - Test Project ID : 1','E_WARNING\nmb_strlen(): Unknown encoding &quot;&quot; - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(163,4,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: tlCfg - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(164,4,2,'GUI - Test Project ID : 1','E_NOTICE\nTrying to get property \'charset\' of non-object - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(165,4,2,'GUI - Test Project ID : 1','E_WARNING\nmb_strlen(): Unknown encoding &quot;&quot; - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1540',1793029139,'PHP',0,NULL),(166,4,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: tlCfg - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(167,4,2,'GUI - Test Project ID : 1','E_NOTICE\nTrying to get property \'charset\' of non-object - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(168,4,2,'GUI - Test Project ID : 1','E_WARNING\nmb_strlen(): Unknown encoding &quot;&quot; - in /var/www/html/lib/functions/requirement_mgr.class.php - Line 1545',1793029139,'PHP',0,NULL),(169,5,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:23:\"audit_reqv_assigned_tcv\";s:6:\"params\";a:4:{i:0;s:37:\"Invitation carries a permission level\";i:1;s:1:\"1\";i:2;s:44:\"Owner invites same-faculty student as VIEWER\";i:3;s:1:\"1\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029140,'ASSIGN',0,NULL),(170,5,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:23:\"audit_reqv_assigned_tcv\";s:6:\"params\";a:4:{i:0;s:27:\"Owner manages collaborators\";i:1;s:1:\"1\";i:2;s:44:\"Owner invites same-faculty student as VIEWER\";i:3;s:1:\"1\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029140,'ASSIGN',0,NULL),(171,5,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:23:\"audit_reqv_assigned_tcv\";s:6:\"params\";a:4:{i:0;s:19:\"Event notifications\";i:1;s:1:\"1\";i:2;s:44:\"Owner invites same-faculty student as VIEWER\";i:3;s:1:\"1\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029140,'ASSIGN',0,NULL),(172,6,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:23:\"audit_reqv_assigned_tcv\";s:6:\"params\";a:4:{i:0;s:37:\"Invitation carries a permission level\";i:1;s:1:\"1\";i:2;s:49:\"Owner invites same-faculty student as CONTRIBUTOR\";i:3;s:1:\"1\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029140,'ASSIGN',0,NULL),(173,6,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:23:\"audit_reqv_assigned_tcv\";s:6:\"params\";a:4:{i:0;s:27:\"Owner manages collaborators\";i:1;s:1:\"1\";i:2;s:49:\"Owner invites same-faculty student as CONTRIBUTOR\";i:3;s:1:\"1\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029140,'ASSIGN',0,NULL),(174,7,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:23:\"audit_reqv_assigned_tcv\";s:6:\"params\";a:4:{i:0;s:46:\"Only the course owner can invite collaborators\";i:1;s:1:\"1\";i:2;s:37:\"Non-owner cannot invite collaborators\";i:3;s:1:\"1\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029140,'ASSIGN',0,NULL),(175,8,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:23:\"audit_reqv_assigned_tcv\";s:6:\"params\";a:4:{i:0;s:32:\"Invalid invitations are rejected\";i:1;s:1:\"1\";i:2;s:27:\"Owner cannot invite himself\";i:3;s:1:\"1\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029140,'ASSIGN',0,NULL),(176,9,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:23:\"audit_reqv_assigned_tcv\";s:6:\"params\";a:4:{i:0;s:32:\"Invalid invitations are rejected\";i:1;s:1:\"1\";i:2;s:52:\"Duplicate invitation to the same student is rejected\";i:3;s:1:\"1\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029140,'ASSIGN',0,NULL),(177,10,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:23:\"audit_reqv_assigned_tcv\";s:6:\"params\";a:4:{i:0;s:46:\"Only the course owner can invite collaborators\";i:1;s:1:\"1\";i:2;s:38:\"Invite to a course that does not exist\";i:3;s:1:\"1\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029140,'ASSIGN',0,NULL),(178,11,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:23:\"audit_reqv_assigned_tcv\";s:6:\"params\";a:4:{i:0;s:26:\"Faculty-restricted sharing\";i:1;s:1:\"1\";i:2;s:59:\"Invitation to a student from a different faculty is blocked\";i:3;s:1:\"1\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029140,'ASSIGN',0,NULL),(179,12,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:23:\"audit_reqv_assigned_tcv\";s:6:\"params\";a:4:{i:0;s:27:\"Owner manages collaborators\";i:1;s:1:\"1\";i:2;s:62:\"Owner changes collaborator permission and removes collaborator\";i:3;s:1:\"1\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029140,'ASSIGN',0,NULL),(180,13,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:23:\"audit_reqv_assigned_tcv\";s:6:\"params\";a:4:{i:0;s:48:\"Invitee accepts or declines a pending invitation\";i:1;s:1:\"1\";i:2;s:43:\"Invitee accepts a pending course invitation\";i:3;s:1:\"1\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029141,'ASSIGN',0,NULL),(181,13,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:23:\"audit_reqv_assigned_tcv\";s:6:\"params\";a:4:{i:0;s:19:\"Event notifications\";i:1;s:1:\"1\";i:2;s:43:\"Invitee accepts a pending course invitation\";i:3;s:1:\"1\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029141,'ASSIGN',0,NULL),(182,14,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:23:\"audit_reqv_assigned_tcv\";s:6:\"params\";a:4:{i:0;s:48:\"Invitee accepts or declines a pending invitation\";i:1;s:1:\"1\";i:2;s:44:\"Invitee declines a pending course invitation\";i:3;s:1:\"1\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029141,'ASSIGN',0,NULL),(183,14,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:23:\"audit_reqv_assigned_tcv\";s:6:\"params\";a:4:{i:0;s:19:\"Event notifications\";i:1;s:1:\"1\";i:2;s:44:\"Invitee declines a pending course invitation\";i:3;s:1:\"1\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029141,'ASSIGN',0,NULL),(184,15,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:23:\"audit_reqv_assigned_tcv\";s:6:\"params\";a:4:{i:0;s:48:\"Invitee accepts or declines a pending invitation\";i:1;s:1:\"1\";i:2;s:56:\"Answered invitation cannot be accepted or declined again\";i:3;s:1:\"1\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029141,'ASSIGN',0,NULL),(185,16,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:23:\"audit_reqv_assigned_tcv\";s:6:\"params\";a:4:{i:0;s:27:\"VIEWER has read-only access\";i:1;s:1:\"1\";i:2;s:46:\"VIEWER can view and download but cannot modify\";i:3;s:1:\"1\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029141,'ASSIGN',0,NULL),(186,17,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:23:\"audit_reqv_assigned_tcv\";s:6:\"params\";a:4:{i:0;s:34:\"CONTRIBUTOR can add but not delete\";i:1;s:1:\"1\";i:2;s:46:\"CONTRIBUTOR can add resources and upload files\";i:3;s:1:\"1\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029141,'ASSIGN',0,NULL),(187,18,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:23:\"audit_reqv_assigned_tcv\";s:6:\"params\";a:4:{i:0;s:34:\"CONTRIBUTOR can add but not delete\";i:1;s:1:\"1\";i:2;s:49:\"CONTRIBUTOR cannot delete resources or the course\";i:3;s:1:\"1\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029141,'ASSIGN',0,NULL),(188,19,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:23:\"audit_reqv_assigned_tcv\";s:6:\"params\";a:4:{i:0;s:48:\"Invitee accepts or declines a pending invitation\";i:1;s:1:\"1\";i:2;s:63:\"Non-collaborator and declined user cannot open a private course\";i:3;s:1:\"1\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029141,'ASSIGN',0,NULL),(189,19,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:23:\"audit_reqv_assigned_tcv\";s:6:\"params\";a:4:{i:0;s:27:\"VIEWER has read-only access\";i:1;s:1:\"1\";i:2;s:63:\"Non-collaborator and declined user cannot open a private course\";i:3;s:1:\"1\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029141,'ASSIGN',0,NULL),(190,20,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:23:\"audit_reqv_assigned_tcv\";s:6:\"params\";a:4:{i:0;s:27:\"New article starts as DRAFT\";i:1;s:1:\"1\";i:2;s:42:\"Create article saved as draft (valid data)\";i:3;s:1:\"1\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029141,'ASSIGN',0,NULL),(191,20,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:23:\"audit_reqv_assigned_tcv\";s:6:\"params\";a:4:{i:0;s:11:\"My Articles\";i:1;s:1:\"1\";i:2;s:42:\"Create article saved as draft (valid data)\";i:3;s:1:\"1\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029141,'ASSIGN',0,NULL),(192,21,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:23:\"audit_reqv_assigned_tcv\";s:6:\"params\";a:4:{i:0;s:24:\"Article input validation\";i:1;s:1:\"1\";i:2;s:51:\"Title length boundaries (0, 1, 200, 201 characters)\";i:3;s:1:\"1\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029141,'ASSIGN',0,NULL),(193,22,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:23:\"audit_reqv_assigned_tcv\";s:6:\"params\";a:4:{i:0;s:24:\"Article input validation\";i:1;s:1:\"1\";i:2;s:48:\"Excerpt length boundaries (500 / 501 characters)\";i:3;s:1:\"1\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029141,'ASSIGN',0,NULL),(194,23,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:23:\"audit_reqv_assigned_tcv\";s:6:\"params\";a:4:{i:0;s:24:\"Article input validation\";i:1;s:1:\"1\";i:2;s:26:\"Cover image URL validation\";i:3;s:1:\"1\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029142,'ASSIGN',0,NULL),(195,24,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:23:\"audit_reqv_assigned_tcv\";s:6:\"params\";a:4:{i:0;s:15:\"Unique URL slug\";i:1;s:1:\"1\";i:2;s:33:\"Duplicate titles get unique slugs\";i:3;s:1:\"1\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029142,'ASSIGN',0,NULL),(196,25,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:23:\"audit_reqv_assigned_tcv\";s:6:\"params\";a:4:{i:0;s:16:\"Edit own article\";i:1;s:1:\"1\";i:2;s:43:\"Author edits own article; tags are replaced\";i:3;s:1:\"1\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029142,'ASSIGN',0,NULL),(197,25,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:23:\"audit_reqv_assigned_tcv\";s:6:\"params\";a:4:{i:0;s:15:\"Unique URL slug\";i:1;s:1:\"1\";i:2;s:43:\"Author edits own article; tags are replaced\";i:3;s:1:\"1\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029142,'ASSIGN',0,NULL),(198,26,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:23:\"audit_reqv_assigned_tcv\";s:6:\"params\";a:4:{i:0;s:16:\"Edit own article\";i:1;s:1:\"1\";i:2;s:39:\"User cannot edit another user\'s article\";i:3;s:1:\"1\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029142,'ASSIGN',0,NULL),(199,27,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:23:\"audit_reqv_assigned_tcv\";s:6:\"params\";a:4:{i:0;s:16:\"Publish workflow\";i:1;s:1:\"1\";i:2;s:23:\"Publish a draft article\";i:3;s:1:\"1\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029142,'ASSIGN',0,NULL),(200,28,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:23:\"audit_reqv_assigned_tcv\";s:6:\"params\";a:4:{i:0;s:16:\"Publish workflow\";i:1;s:1:\"1\";i:2;s:36:\"Only DRAFT articles can be published\";i:3;s:1:\"1\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029142,'ASSIGN',0,NULL),(201,29,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:23:\"audit_reqv_assigned_tcv\";s:6:\"params\";a:4:{i:0;s:30:\"Archive and delete own article\";i:1;s:1:\"1\";i:2;s:29:\"Archive own published article\";i:3;s:1:\"1\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029142,'ASSIGN',0,NULL),(202,29,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:23:\"audit_reqv_assigned_tcv\";s:6:\"params\";a:4:{i:0;s:22:\"Public article listing\";i:1;s:1:\"1\";i:2;s:29:\"Archive own published article\";i:3;s:1:\"1\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029142,'ASSIGN',0,NULL),(203,30,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:23:\"audit_reqv_assigned_tcv\";s:6:\"params\";a:4:{i:0;s:30:\"Archive and delete own article\";i:1;s:1:\"1\";i:2;s:18:\"Delete own article\";i:3;s:1:\"1\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029142,'ASSIGN',0,NULL),(204,31,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:23:\"audit_reqv_assigned_tcv\";s:6:\"params\";a:4:{i:0;s:16:\"Publish workflow\";i:1;s:1:\"1\";i:2;s:44:\"Non-author cannot publish, archive or delete\";i:3;s:1:\"1\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029142,'ASSIGN',0,NULL),(205,31,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:23:\"audit_reqv_assigned_tcv\";s:6:\"params\";a:4:{i:0;s:30:\"Archive and delete own article\";i:1;s:1:\"1\";i:2;s:44:\"Non-author cannot publish, archive or delete\";i:3;s:1:\"1\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029142,'ASSIGN',0,NULL),(206,32,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:23:\"audit_reqv_assigned_tcv\";s:6:\"params\";a:4:{i:0;s:22:\"Article access control\";i:1;s:1:\"1\";i:2;s:35:\"Access control by status and viewer\";i:3;s:1:\"1\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029142,'ASSIGN',0,NULL),(207,33,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:23:\"audit_reqv_assigned_tcv\";s:6:\"params\";a:4:{i:0;s:22:\"Public article listing\";i:1;s:1:\"1\";i:2;s:59:\"Listing shows only published, newest first, with pagination\";i:3;s:1:\"1\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029142,'ASSIGN',0,NULL),(208,34,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:23:\"audit_reqv_assigned_tcv\";s:6:\"params\";a:4:{i:0;s:22:\"Public article listing\";i:1;s:1:\"1\";i:2;s:21:\"Search and tag filter\";i:3;s:1:\"1\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029143,'ASSIGN',0,NULL),(209,35,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:23:\"audit_reqv_assigned_tcv\";s:6:\"params\";a:4:{i:0;s:12:\"View counter\";i:1;s:1:\"1\";i:2;s:51:\"View counter increments only for published articles\";i:3;s:1:\"1\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029143,'ASSIGN',0,NULL),(210,36,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:23:\"audit_reqv_assigned_tcv\";s:6:\"params\";a:4:{i:0;s:11:\"My Articles\";i:1;s:1:\"1\";i:2;s:25:\"My Articles status filter\";i:3;s:1:\"1\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029143,'ASSIGN',0,NULL),(211,37,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:23:\"audit_reqv_assigned_tcv\";s:6:\"params\";a:4:{i:0;s:12:\"Unread badge\";i:1;s:1:\"1\";i:2;s:37:\"Unread badge boundaries (0, 1, 9, 10)\";i:3;s:1:\"1\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029143,'ASSIGN',0,NULL),(212,38,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:23:\"audit_reqv_assigned_tcv\";s:6:\"params\";a:4:{i:0;s:29:\"Recent notifications dropdown\";i:1;s:1:\"1\";i:2;s:43:\"Dropdown lists 20 most recent, newest first\";i:3;s:1:\"1\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029143,'ASSIGN',0,NULL),(213,39,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:23:\"audit_reqv_assigned_tcv\";s:6:\"params\";a:4:{i:0;s:16:\"Mark one as read\";i:1;s:1:\"1\";i:2;s:70:\"Click invitation notification marks read and opens Pending Invitations\";i:3;s:1:\"1\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029143,'ASSIGN',0,NULL),(214,39,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:23:\"audit_reqv_assigned_tcv\";s:6:\"params\";a:4:{i:0;s:48:\"Invitee accepts or declines a pending invitation\";i:1;s:1:\"1\";i:2;s:70:\"Click invitation notification marks read and opens Pending Invitations\";i:3;s:1:\"1\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029143,'ASSIGN',0,NULL),(215,40,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:23:\"audit_reqv_assigned_tcv\";s:6:\"params\";a:4:{i:0;s:16:\"Mark all as read\";i:1;s:1:\"1\";i:2;s:16:\"Mark all as read\";i:3;s:1:\"1\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029143,'ASSIGN',0,NULL),(216,41,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:23:\"audit_reqv_assigned_tcv\";s:6:\"params\";a:4:{i:0;s:20:\"Notification privacy\";i:1;s:1:\"1\";i:2;s:52:\"User cannot read or mark another user\'s notification\";i:3;s:1:\"1\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029143,'ASSIGN',0,NULL),(217,42,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:23:\"audit_reqv_assigned_tcv\";s:6:\"params\";a:4:{i:0;s:25:\"Full notification history\";i:1;s:1:\"1\";i:2;s:39:\"View all notifications page with paging\";i:3;s:1:\"1\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029143,'ASSIGN',0,NULL),(218,43,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:23:\"audit_reqv_assigned_tcv\";s:6:\"params\";a:4:{i:0;s:24:\"Notification preferences\";i:1;s:1:\"1\";i:2;s:46:\"Default preferences are created on first visit\";i:3;s:1:\"1\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029143,'ASSIGN',0,NULL),(219,44,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:23:\"audit_reqv_assigned_tcv\";s:6:\"params\";a:4:{i:0;s:24:\"Notification preferences\";i:1;s:1:\"1\";i:2;s:40:\"Save in-app / email preferences per type\";i:3;s:1:\"1\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029143,'ASSIGN',0,NULL),(220,45,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:23:\"audit_reqv_assigned_tcv\";s:6:\"params\";a:4:{i:0;s:21:\"Reminder timing range\";i:1;s:1:\"1\";i:2;s:32:\"Class reminder timing boundaries\";i:3;s:1:\"1\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029144,'ASSIGN',0,NULL),(221,46,16,'GUI - Test Project ID : 1','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:21:\"audit_login_succeeded\";s:6:\"params\";a:2:{i:0;s:4:\"rawa\";i:1;s:12:\"192.168.65.1\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1793029188,'LOGIN',2,'users'),(222,47,2,'GUI - Test Project ID : 1','E_WARNING\ngetimagesize(http://localhost:8090/gui/themes/default/images/tl-logo-transparent-25.png): failed to open stream: Connection refused - in /var/www/html/lib/functions/print.inc.php - Line 694',1793029188,'PHP',0,NULL),(223,47,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029188,'PHP',0,NULL),(224,47,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029188,'PHP',0,NULL),(225,47,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029188,'PHP',0,NULL),(226,47,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029188,'PHP',0,NULL),(227,47,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029188,'PHP',0,NULL),(228,47,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029188,'PHP',0,NULL),(229,47,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029188,'PHP',0,NULL),(230,47,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029188,'PHP',0,NULL),(231,47,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029188,'PHP',0,NULL),(232,47,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029188,'PHP',0,NULL),(233,47,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029188,'PHP',0,NULL),(234,47,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029188,'PHP',0,NULL),(235,47,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029188,'PHP',0,NULL),(236,47,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029188,'PHP',0,NULL),(237,47,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029188,'PHP',0,NULL),(238,47,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029188,'PHP',0,NULL),(239,47,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029188,'PHP',0,NULL),(240,47,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029188,'PHP',0,NULL),(241,47,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029188,'PHP',0,NULL),(242,47,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029188,'PHP',0,NULL),(243,47,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029188,'PHP',0,NULL),(244,47,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029188,'PHP',0,NULL),(245,47,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029188,'PHP',0,NULL),(246,47,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029188,'PHP',0,NULL),(247,47,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029188,'PHP',0,NULL),(248,47,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029188,'PHP',0,NULL),(249,47,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029188,'PHP',0,NULL),(250,47,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029188,'PHP',0,NULL),(251,47,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029188,'PHP',0,NULL),(252,47,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029188,'PHP',0,NULL),(253,47,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029188,'PHP',0,NULL),(254,47,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029188,'PHP',0,NULL),(255,47,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029188,'PHP',0,NULL),(256,47,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029188,'PHP',0,NULL),(257,47,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029188,'PHP',0,NULL),(258,47,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029188,'PHP',0,NULL),(259,47,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029188,'PHP',0,NULL),(260,47,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029188,'PHP',0,NULL),(261,47,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029188,'PHP',0,NULL),(262,47,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029188,'PHP',0,NULL),(263,47,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029188,'PHP',0,NULL),(264,48,2,'GUI - Test Project ID : 1','E_WARNING\ngetimagesize(http://localhost:8090/gui/themes/default/images/tl-logo-transparent-25.png): failed to open stream: Connection refused - in /var/www/html/lib/functions/print.inc.php - Line 694',1793029188,'PHP',0,NULL),(265,49,2,'GUI - Test Project ID : 1','E_WARNING\ngetimagesize(http://localhost:8090/gui/themes/default/images/tl-logo-transparent-25.png): failed to open stream: Connection refused - in /var/www/html/lib/functions/print.inc.php - Line 694',1793029203,'PHP',0,NULL),(266,49,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029203,'PHP',0,NULL),(267,49,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029203,'PHP',0,NULL),(268,49,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029203,'PHP',0,NULL),(269,49,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029203,'PHP',0,NULL),(270,49,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029203,'PHP',0,NULL),(271,49,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029203,'PHP',0,NULL),(272,49,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029203,'PHP',0,NULL),(273,49,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029203,'PHP',0,NULL),(274,49,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029203,'PHP',0,NULL),(275,49,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029203,'PHP',0,NULL),(276,49,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029203,'PHP',0,NULL),(277,49,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029203,'PHP',0,NULL),(278,49,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029203,'PHP',0,NULL),(279,49,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029203,'PHP',0,NULL),(280,49,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029203,'PHP',0,NULL),(281,49,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029203,'PHP',0,NULL),(282,49,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029203,'PHP',0,NULL),(283,49,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029203,'PHP',0,NULL),(284,49,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029203,'PHP',0,NULL),(285,49,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029203,'PHP',0,NULL),(286,49,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029203,'PHP',0,NULL),(287,49,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029203,'PHP',0,NULL),(288,49,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029203,'PHP',0,NULL),(289,49,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029203,'PHP',0,NULL),(290,49,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029203,'PHP',0,NULL),(291,49,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029203,'PHP',0,NULL),(292,49,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029203,'PHP',0,NULL),(293,49,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029203,'PHP',0,NULL),(294,49,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029203,'PHP',0,NULL),(295,49,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029203,'PHP',0,NULL),(296,49,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029203,'PHP',0,NULL),(297,49,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029203,'PHP',0,NULL),(298,49,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029203,'PHP',0,NULL),(299,49,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029203,'PHP',0,NULL),(300,49,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029203,'PHP',0,NULL),(301,49,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029203,'PHP',0,NULL),(302,49,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029203,'PHP',0,NULL),(303,49,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029203,'PHP',0,NULL),(304,49,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029203,'PHP',0,NULL),(305,49,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029203,'PHP',0,NULL),(306,49,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029203,'PHP',0,NULL),(307,50,2,'GUI - Test Project ID : 1','E_WARNING\ngetimagesize(http://localhost:8090/gui/themes/default/images/tl-logo-transparent-25.png): failed to open stream: Connection refused - in /var/www/html/lib/functions/print.inc.php - Line 694',1793029203,'PHP',0,NULL),(308,51,2,'GUI - Test Project ID : 1','E_WARNING\ngetimagesize(http://localhost:8090/gui/themes/default/images/tl-logo-transparent-25.png): failed to open stream: Connection refused - in /var/www/html/lib/functions/print.inc.php - Line 694',1793029246,'PHP',0,NULL),(309,51,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029246,'PHP',0,NULL),(310,51,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029246,'PHP',0,NULL),(311,51,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029246,'PHP',0,NULL),(312,51,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029246,'PHP',0,NULL),(313,51,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029246,'PHP',0,NULL),(314,51,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029246,'PHP',0,NULL),(315,51,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029246,'PHP',0,NULL),(316,51,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029246,'PHP',0,NULL),(317,51,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029246,'PHP',0,NULL),(318,51,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029246,'PHP',0,NULL),(319,51,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029246,'PHP',0,NULL),(320,51,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029246,'PHP',0,NULL),(321,51,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029246,'PHP',0,NULL),(322,51,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029246,'PHP',0,NULL),(323,51,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029246,'PHP',0,NULL),(324,51,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029246,'PHP',0,NULL),(325,51,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029246,'PHP',0,NULL),(326,51,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029246,'PHP',0,NULL),(327,51,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029246,'PHP',0,NULL),(328,51,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029246,'PHP',0,NULL),(329,51,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029246,'PHP',0,NULL),(330,51,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029246,'PHP',0,NULL),(331,51,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029246,'PHP',0,NULL),(332,51,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029246,'PHP',0,NULL),(333,51,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029246,'PHP',0,NULL),(334,51,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029246,'PHP',0,NULL),(335,51,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029246,'PHP',0,NULL),(336,51,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029246,'PHP',0,NULL),(337,51,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029246,'PHP',0,NULL),(338,51,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029246,'PHP',0,NULL),(339,51,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029246,'PHP',0,NULL),(340,51,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029246,'PHP',0,NULL),(341,51,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029246,'PHP',0,NULL),(342,51,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029246,'PHP',0,NULL),(343,51,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029246,'PHP',0,NULL),(344,51,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029246,'PHP',0,NULL),(345,51,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029246,'PHP',0,NULL),(346,51,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029246,'PHP',0,NULL),(347,51,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029246,'PHP',0,NULL),(348,51,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029246,'PHP',0,NULL),(349,51,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined index: platform - in /var/www/html/lib/functions/print.inc.php - Line 1472',1793029246,'PHP',0,NULL),(350,52,2,'GUI - Test Project ID : 1','E_WARNING\ngetimagesize(http://localhost:8090/gui/themes/default/images/tl-logo-transparent-25.png): failed to open stream: Connection refused - in /var/www/html/lib/functions/print.inc.php - Line 694',1793029249,'PHP',0,NULL),(351,53,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: attachXML - in /var/www/html/lib/functions/testsuite.class.php - Line 1242',1793029264,'PHP',0,NULL),(352,53,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: attachXML - in /var/www/html/lib/functions/testsuite.class.php - Line 1242',1793029264,'PHP',0,NULL),(353,53,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: attachXML - in /var/www/html/lib/functions/testsuite.class.php - Line 1242',1793029264,'PHP',0,NULL),(354,53,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: attachXML - in /var/www/html/lib/functions/testsuite.class.php - Line 1242',1793029264,'PHP',0,NULL),(355,53,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: attachXML - in /var/www/html/lib/functions/testsuite.class.php - Line 1242',1793029264,'PHP',0,NULL),(356,53,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: attachXML - in /var/www/html/lib/functions/testsuite.class.php - Line 1242',1793029264,'PHP',0,NULL),(357,53,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: attachXML - in /var/www/html/lib/functions/testsuite.class.php - Line 1242',1793029264,'PHP',0,NULL),(358,53,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: attachXML - in /var/www/html/lib/functions/testsuite.class.php - Line 1242',1793029264,'PHP',0,NULL),(359,53,2,'GUI - Test Project ID : 1','E_NOTICE\nUndefined variable: attachXML - in /var/www/html/lib/functions/testsuite.class.php - Line 1242',1793029264,'PHP',0,NULL),(360,54,2,'GUI','E_NOTICE\nUndefined index: testsuitename - in /var/www/html/lib/api/xmlrpc/v1/xmlrpc.class.php - Line 4393',1793029475,'PHP',0,NULL);
/*!40000 ALTER TABLE `events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `exec_by_date_time`
--

DROP TABLE IF EXISTS `exec_by_date_time`;
/*!50001 DROP VIEW IF EXISTS `exec_by_date_time`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `exec_by_date_time` AS SELECT
 NULL AS `testplan_name`,
 NULL AS `yyyy_mm_dd`,
 NULL AS `yyyy_mm`,
 NULL AS `hh`,
 NULL AS `hour`,
 NULL AS `id`,
 NULL AS `build_id`,
 NULL AS `tester_id`,
 NULL AS `execution_ts`,
 NULL AS `status`,
 NULL AS `testplan_id`,
 NULL AS `tcversion_id`,
 NULL AS `tcversion_number`,
 NULL AS `platform_id`,
 NULL AS `execution_type`,
 NULL AS `execution_duration`,
 NULL AS `notes` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `execution_bugs`
--

DROP TABLE IF EXISTS `execution_bugs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `execution_bugs` (
  `execution_id` int(10) unsigned NOT NULL DEFAULT 0,
  `bug_id` varchar(64) NOT NULL DEFAULT '0',
  `tcstep_id` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`execution_id`,`bug_id`,`tcstep_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `execution_bugs`
--

LOCK TABLES `execution_bugs` WRITE;
/*!40000 ALTER TABLE `execution_bugs` DISABLE KEYS */;
/*!40000 ALTER TABLE `execution_bugs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `execution_tcsteps`
--

DROP TABLE IF EXISTS `execution_tcsteps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `execution_tcsteps` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `execution_id` int(10) unsigned NOT NULL DEFAULT 0,
  `tcstep_id` int(10) unsigned NOT NULL DEFAULT 0,
  `notes` text DEFAULT NULL,
  `status` char(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `execution_tcsteps_idx1` (`execution_id`,`tcstep_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `execution_tcsteps`
--

LOCK TABLES `execution_tcsteps` WRITE;
/*!40000 ALTER TABLE `execution_tcsteps` DISABLE KEYS */;
/*!40000 ALTER TABLE `execution_tcsteps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `execution_tcsteps_wip`
--

DROP TABLE IF EXISTS `execution_tcsteps_wip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `execution_tcsteps_wip` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tcstep_id` int(10) unsigned NOT NULL DEFAULT 0,
  `testplan_id` int(10) unsigned NOT NULL DEFAULT 0,
  `platform_id` int(10) unsigned NOT NULL DEFAULT 0,
  `build_id` int(10) unsigned NOT NULL DEFAULT 0,
  `tester_id` int(10) unsigned DEFAULT NULL,
  `creation_ts` timestamp NOT NULL DEFAULT current_timestamp(),
  `notes` text DEFAULT NULL,
  `status` char(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `execution_tcsteps_wip_idx1` (`tcstep_id`,`testplan_id`,`platform_id`,`build_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `execution_tcsteps_wip`
--

LOCK TABLES `execution_tcsteps_wip` WRITE;
/*!40000 ALTER TABLE `execution_tcsteps_wip` DISABLE KEYS */;
/*!40000 ALTER TABLE `execution_tcsteps_wip` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `executions`
--

DROP TABLE IF EXISTS `executions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `executions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `build_id` int(10) NOT NULL DEFAULT 0,
  `tester_id` int(10) unsigned DEFAULT NULL,
  `execution_ts` datetime DEFAULT NULL,
  `status` char(1) DEFAULT NULL,
  `testplan_id` int(10) unsigned NOT NULL DEFAULT 0,
  `tcversion_id` int(10) unsigned NOT NULL DEFAULT 0,
  `tcversion_number` smallint(5) unsigned NOT NULL DEFAULT 1,
  `platform_id` int(10) unsigned NOT NULL DEFAULT 0,
  `execution_type` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1 -> manual, 2 -> automated',
  `execution_duration` decimal(6,2) DEFAULT NULL COMMENT 'NULL will be considered as NO DATA Provided by user',
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `executions_idx1` (`testplan_id`,`tcversion_id`,`platform_id`,`build_id`),
  KEY `executions_idx2` (`execution_type`),
  KEY `executions_idx3` (`tcversion_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `executions`
--

LOCK TABLES `executions` WRITE;
/*!40000 ALTER TABLE `executions` DISABLE KEYS */;
/*!40000 ALTER TABLE `executions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory`
--

DROP TABLE IF EXISTS `inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `testproject_id` int(10) unsigned NOT NULL,
  `owner_id` int(10) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `content` text DEFAULT NULL,
  `creation_ts` timestamp NOT NULL DEFAULT current_timestamp(),
  `modification_ts` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `inventory_idx1` (`testproject_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory`
--

LOCK TABLES `inventory` WRITE;
/*!40000 ALTER TABLE `inventory` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `issuetrackers`
--

DROP TABLE IF EXISTS `issuetrackers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `issuetrackers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `type` int(10) DEFAULT 0,
  `cfg` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `issuetrackers_uidx1` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `issuetrackers`
--

LOCK TABLES `issuetrackers` WRITE;
/*!40000 ALTER TABLE `issuetrackers` DISABLE KEYS */;
/*!40000 ALTER TABLE `issuetrackers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `keywords`
--

DROP TABLE IF EXISTS `keywords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `keywords` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `keyword` varchar(100) NOT NULL DEFAULT '',
  `testproject_id` int(10) unsigned NOT NULL DEFAULT 0,
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `keyword_testproject_id` (`keyword`,`testproject_id`),
  KEY `testproject_id` (`testproject_id`),
  KEY `keyword` (`keyword`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `keywords`
--

LOCK TABLES `keywords` WRITE;
/*!40000 ALTER TABLE `keywords` DISABLE KEYS */;
/*!40000 ALTER TABLE `keywords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `latest_exec_by_context`
--

DROP TABLE IF EXISTS `latest_exec_by_context`;
/*!50001 DROP VIEW IF EXISTS `latest_exec_by_context`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `latest_exec_by_context` AS SELECT
 NULL AS `tcversion_id`,
 NULL AS `testplan_id`,
 NULL AS `build_id`,
 NULL AS `platform_id`,
 NULL AS `id` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `latest_exec_by_testplan`
--

DROP TABLE IF EXISTS `latest_exec_by_testplan`;
/*!50001 DROP VIEW IF EXISTS `latest_exec_by_testplan`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `latest_exec_by_testplan` AS SELECT
 NULL AS `tcversion_id`,
 NULL AS `testplan_id`,
 NULL AS `id` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `latest_exec_by_testplan_plat`
--

DROP TABLE IF EXISTS `latest_exec_by_testplan_plat`;
/*!50001 DROP VIEW IF EXISTS `latest_exec_by_testplan_plat`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `latest_exec_by_testplan_plat` AS SELECT
 NULL AS `tcversion_id`,
 NULL AS `testplan_id`,
 NULL AS `platform_id`,
 NULL AS `id` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `latest_req_version`
--

DROP TABLE IF EXISTS `latest_req_version`;
/*!50001 DROP VIEW IF EXISTS `latest_req_version`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `latest_req_version` AS SELECT
 NULL AS `req_id`,
 NULL AS `version` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `latest_req_version_id`
--

DROP TABLE IF EXISTS `latest_req_version_id`;
/*!50001 DROP VIEW IF EXISTS `latest_req_version_id`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `latest_req_version_id` AS SELECT
 NULL AS `req_id`,
 NULL AS `version`,
 NULL AS `req_version_id` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `latest_rspec_revision`
--

DROP TABLE IF EXISTS `latest_rspec_revision`;
/*!50001 DROP VIEW IF EXISTS `latest_rspec_revision`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `latest_rspec_revision` AS SELECT
 NULL AS `req_spec_id`,
 NULL AS `testproject_id`,
 NULL AS `revision` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `latest_tcase_version_id`
--

DROP TABLE IF EXISTS `latest_tcase_version_id`;
/*!50001 DROP VIEW IF EXISTS `latest_tcase_version_id`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `latest_tcase_version_id` AS SELECT
 NULL AS `testcase_id`,
 NULL AS `version`,
 NULL AS `tcversion_id` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `latest_tcase_version_number`
--

DROP TABLE IF EXISTS `latest_tcase_version_number`;
/*!50001 DROP VIEW IF EXISTS `latest_tcase_version_number`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `latest_tcase_version_number` AS SELECT
 NULL AS `testcase_id`,
 NULL AS `version` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `milestones`
--

DROP TABLE IF EXISTS `milestones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `milestones` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `testplan_id` int(10) unsigned NOT NULL DEFAULT 0,
  `target_date` date NOT NULL,
  `start_date` date DEFAULT NULL,
  `a` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `b` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `c` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `name` varchar(100) NOT NULL DEFAULT 'undefined',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_testplan_id` (`name`,`testplan_id`),
  KEY `testplan_id` (`testplan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `milestones`
--

LOCK TABLES `milestones` WRITE;
/*!40000 ALTER TABLE `milestones` DISABLE KEYS */;
/*!40000 ALTER TABLE `milestones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `node_types`
--

DROP TABLE IF EXISTS `node_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `node_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `description` varchar(100) NOT NULL DEFAULT 'testproject',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `node_types`
--

LOCK TABLES `node_types` WRITE;
/*!40000 ALTER TABLE `node_types` DISABLE KEYS */;
INSERT INTO `node_types` VALUES (1,'testproject'),(2,'testsuite'),(3,'testcase'),(4,'testcase_version'),(5,'testplan'),(6,'requirement_spec'),(7,'requirement'),(8,'requirement_version'),(9,'testcase_step'),(10,'requirement_revision'),(11,'requirement_spec_revision'),(12,'build'),(13,'platform'),(14,'user');
/*!40000 ALTER TABLE `node_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nodes_hierarchy`
--

DROP TABLE IF EXISTS `nodes_hierarchy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `nodes_hierarchy` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `node_type_id` int(10) unsigned NOT NULL DEFAULT 1,
  `node_order` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pid_m_nodeorder` (`parent_id`,`node_order`),
  KEY `nodes_hierarchy_node_type_id` (`node_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=267 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nodes_hierarchy`
--

LOCK TABLES `nodes_hierarchy` WRITE;
/*!40000 ALTER TABLE `nodes_hierarchy` DISABLE KEYS */;
INSERT INTO `nodes_hierarchy` VALUES (1,'UniShare',NULL,1,1),(2,'UC-S4-001 Course Sharing & Permissions',1,6,1),(3,'UC-S4-001 Course Sharing & Permissions',2,11,0),(4,'Only the course owner can invite collaborators',2,7,1),(5,'',4,8,0),(6,'Invalid invitations are rejected',2,7,2),(7,'',6,8,0),(8,'Invitation carries a permission level',2,7,3),(9,'',8,8,0),(10,'Invitee accepts or declines a pending invitation',2,7,4),(11,'',10,8,0),(12,'VIEWER has read-only access',2,7,5),(13,'',12,8,0),(14,'CONTRIBUTOR can add but not delete',2,7,6),(15,'',14,8,0),(16,'Owner manages collaborators',2,7,7),(17,'',16,8,0),(18,'Faculty-restricted sharing',2,7,8),(19,'',18,8,0),(20,'UC-S4-003 Public Articles',1,6,2),(21,'UC-S4-003 Public Articles',20,11,0),(22,'Article input validation',20,7,1),(23,'',22,8,0),(24,'New article starts as DRAFT',20,7,2),(25,'',24,8,0),(26,'Unique URL slug',20,7,3),(27,'',26,8,0),(28,'Publish workflow',20,7,4),(29,'',28,8,0),(30,'Archive and delete own article',20,7,5),(31,'',30,8,0),(32,'Edit own article',20,7,6),(33,'',32,8,0),(34,'Public article listing',20,7,7),(35,'',34,8,0),(36,'Article access control',20,7,8),(37,'',36,8,0),(38,'View counter',20,7,9),(39,'',38,8,0),(40,'My Articles',20,7,10),(41,'',40,8,0),(42,'UC-S4-004 Notifications',1,6,3),(43,'UC-S4-004 Notifications',42,11,0),(44,'Event notifications',42,7,1),(45,'',44,8,0),(46,'Unread badge',42,7,2),(47,'',46,8,0),(48,'Recent notifications dropdown',42,7,3),(49,'',48,8,0),(50,'Mark one as read',42,7,4),(51,'',50,8,0),(52,'Mark all as read',42,7,5),(53,'',52,8,0),(54,'Notification privacy',42,7,6),(55,'',54,8,0),(56,'Notification preferences',42,7,7),(57,'',56,8,0),(58,'Reminder timing range',42,7,8),(59,'',58,8,0),(60,'Full notification history',42,7,9),(61,'',60,8,0),(62,'Rawa Dara - Sharing, Articles & Notifications (Iteration 4)',1,2,0),(63,'TS-R1 Share Course (UC-S4-001)',62,2,1),(64,'Owner invites same-faculty student as VIEWER',63,3,1),(65,'',64,4,0),(66,'',65,9,0),(67,'',65,9,0),(68,'',65,9,0),(69,'',65,9,0),(70,'Owner invites same-faculty student as CONTRIBUTOR',63,3,2),(71,'',70,4,0),(72,'',71,9,0),(73,'',71,9,0),(74,'Non-owner cannot invite collaborators',63,3,3),(75,'',74,4,0),(76,'',75,9,0),(77,'',75,9,0),(78,'Owner cannot invite himself',63,3,4),(79,'',78,4,0),(80,'',79,9,0),(81,'Duplicate invitation to the same student is rejected',63,3,5),(82,'',81,4,0),(83,'',82,9,0),(84,'',82,9,0),(85,'Invite to a course that does not exist',63,3,6),(86,'',85,4,0),(87,'',86,9,0),(88,'Invitation to a student from a different faculty is blocked',63,3,7),(89,'',88,4,0),(90,'',89,9,0),(91,'',89,9,0),(92,'Owner changes collaborator permission and removes collaborator',63,3,8),(93,'',92,4,0),(94,'',93,9,0),(95,'',93,9,0),(96,'',93,9,0),(97,'TS-R2 Respond to Course Invitation',62,2,2),(98,'Invitee accepts a pending course invitation',97,3,1),(99,'',98,4,0),(100,'',99,9,0),(101,'',99,9,0),(102,'',99,9,0),(103,'',99,9,0),(104,'Invitee declines a pending course invitation',97,3,2),(105,'',104,4,0),(106,'',105,9,0),(107,'',105,9,0),(108,'',105,9,0),(109,'Answered invitation cannot be accepted or declined again',97,3,3),(110,'',109,4,0),(111,'',110,9,0),(112,'',110,9,0),(113,'TS-R3 Shared Course Permissions (Viewer / Contributor)',62,2,3),(114,'VIEWER can view and download but cannot modify',113,3,1),(115,'',114,4,0),(116,'',115,9,0),(117,'',115,9,0),(118,'',115,9,0),(119,'',115,9,0),(120,'',115,9,0),(121,'CONTRIBUTOR can add resources and upload files',113,3,2),(122,'',121,4,0),(123,'',122,9,0),(124,'',122,9,0),(125,'',122,9,0),(126,'CONTRIBUTOR cannot delete resources or the course',113,3,3),(127,'',126,4,0),(128,'',127,9,0),(129,'',127,9,0),(130,'Non-collaborator and declined user cannot open a private course',113,3,4),(131,'',130,4,0),(132,'',131,9,0),(133,'',131,9,0),(134,'TS-R4 Create & Edit Article (UC-S4-003)',62,2,4),(135,'Create article saved as draft (valid data)',134,3,1),(136,'',135,4,0),(137,'',136,9,0),(138,'',136,9,0),(139,'',136,9,0),(140,'Title length boundaries (0, 1, 200, 201 characters)',134,3,2),(141,'',140,4,0),(142,'',141,9,0),(143,'',141,9,0),(144,'',141,9,0),(145,'',141,9,0),(146,'',141,9,0),(147,'Excerpt length boundaries (500 / 501 characters)',134,3,3),(148,'',147,4,0),(149,'',148,9,0),(150,'',148,9,0),(151,'',148,9,0),(152,'',148,9,0),(153,'Cover image URL validation',134,3,4),(154,'',153,4,0),(155,'',154,9,0),(156,'',154,9,0),(157,'',154,9,0),(158,'Duplicate titles get unique slugs',134,3,5),(159,'',158,4,0),(160,'',159,9,0),(161,'',159,9,0),(162,'',159,9,0),(163,'Author edits own article; tags are replaced',134,3,6),(164,'',163,4,0),(165,'',164,9,0),(166,'',164,9,0),(167,'User cannot edit another user\'s article',134,3,7),(168,'',167,4,0),(169,'',168,9,0),(170,'',168,9,0),(171,'TS-R5 Article Lifecycle (Publish / Archive / Delete)',62,2,5),(172,'Publish a draft article',171,3,1),(173,'',172,4,0),(174,'',173,9,0),(175,'',173,9,0),(176,'Only DRAFT articles can be published',171,3,2),(177,'',176,4,0),(178,'',177,9,0),(179,'',177,9,0),(180,'Archive own published article',171,3,3),(181,'',180,4,0),(182,'',181,9,0),(183,'',181,9,0),(184,'Delete own article',171,3,4),(185,'',184,4,0),(186,'',185,9,0),(187,'',185,9,0),(188,'Non-author cannot publish, archive or delete',171,3,5),(189,'',188,4,0),(190,'',189,9,0),(191,'',189,9,0),(192,'',189,9,0),(193,'',189,9,0),(194,'TS-R6 Browse & Read Public Articles',62,2,6),(195,'Access control by status and viewer',194,3,1),(196,'',195,4,0),(197,'',196,9,0),(198,'',196,9,0),(199,'',196,9,0),(200,'',196,9,0),(201,'',196,9,0),(202,'Listing shows only published, newest first, with pagination',194,3,2),(203,'',202,4,0),(204,'',203,9,0),(205,'',203,9,0),(206,'',203,9,0),(207,'Search and tag filter',194,3,3),(208,'',207,4,0),(209,'',208,9,0),(210,'',208,9,0),(211,'',208,9,0),(212,'',208,9,0),(213,'',208,9,0),(214,'View counter increments only for published articles',194,3,4),(215,'',214,4,0),(216,'',215,9,0),(217,'',215,9,0),(218,'',215,9,0),(219,'My Articles status filter',194,3,5),(220,'',219,4,0),(221,'',220,9,0),(222,'',220,9,0),(223,'TS-R7 Notification Centre (UC-S4-004)',62,2,7),(224,'Unread badge boundaries (0, 1, 9, 10)',223,3,1),(225,'',224,4,0),(226,'',225,9,0),(227,'',225,9,0),(228,'',225,9,0),(229,'',225,9,0),(230,'Dropdown lists 20 most recent, newest first',223,3,2),(231,'',230,4,0),(232,'',231,9,0),(233,'',231,9,0),(234,'Click invitation notification marks read and opens Pending Invitations',223,3,3),(235,'',234,4,0),(236,'',235,9,0),(237,'',235,9,0),(238,'Mark all as read',223,3,4),(239,'',238,4,0),(240,'',239,9,0),(241,'',239,9,0),(242,'User cannot read or mark another user\'s notification',223,3,5),(243,'',242,4,0),(244,'',243,9,0),(245,'',243,9,0),(246,'View all notifications page with paging',223,3,6),(247,'',246,4,0),(248,'',247,9,0),(249,'',247,9,0),(250,'',247,9,0),(251,'TS-R8 Notification Preferences',62,2,8),(252,'Default preferences are created on first visit',251,3,1),(253,'',252,4,0),(254,'',253,9,0),(255,'Save in-app / email preferences per type',251,3,2),(256,'',255,4,0),(257,'',256,9,0),(258,'',256,9,0),(259,'',256,9,0),(260,'Class reminder timing boundaries',251,3,3),(261,'',260,4,0),(262,'',261,9,0),(263,'',261,9,0),(264,'',261,9,0),(265,'',261,9,0),(266,'Project 1 - Test Case Design',1,5,0);
/*!40000 ALTER TABLE `nodes_hierarchy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_keywords`
--

DROP TABLE IF EXISTS `object_keywords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `object_keywords` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fk_id` int(10) unsigned NOT NULL DEFAULT 0,
  `fk_table` varchar(30) DEFAULT '',
  `keyword_id` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `udx01_object_keywords` (`fk_id`,`fk_table`,`keyword_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_keywords`
--

LOCK TABLES `object_keywords` WRITE;
/*!40000 ALTER TABLE `object_keywords` DISABLE KEYS */;
/*!40000 ALTER TABLE `object_keywords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `platforms`
--

DROP TABLE IF EXISTS `platforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `platforms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `testproject_id` int(10) unsigned NOT NULL,
  `notes` text NOT NULL,
  `enable_on_design` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `enable_on_execution` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `is_open` tinyint(1) unsigned NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_platforms` (`testproject_id`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `platforms`
--

LOCK TABLES `platforms` WRITE;
/*!40000 ALTER TABLE `platforms` DISABLE KEYS */;
/*!40000 ALTER TABLE `platforms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `basename` varchar(100) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 0,
  `author_id` int(10) unsigned DEFAULT NULL,
  `creation_ts` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plugins_configuration`
--

DROP TABLE IF EXISTS `plugins_configuration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `plugins_configuration` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `testproject_id` int(11) NOT NULL,
  `config_key` varchar(255) NOT NULL,
  `config_type` int(11) NOT NULL,
  `config_value` varchar(255) NOT NULL,
  `author_id` int(10) unsigned DEFAULT NULL,
  `creation_ts` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plugins_configuration`
--

LOCK TABLES `plugins_configuration` WRITE;
/*!40000 ALTER TABLE `plugins_configuration` DISABLE KEYS */;
/*!40000 ALTER TABLE `plugins_configuration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `req_coverage`
--

DROP TABLE IF EXISTS `req_coverage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `req_coverage` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `req_id` int(10) NOT NULL,
  `req_version_id` int(10) NOT NULL,
  `testcase_id` int(10) NOT NULL,
  `tcversion_id` int(10) NOT NULL,
  `link_status` int(11) NOT NULL DEFAULT 1,
  `is_active` int(11) NOT NULL DEFAULT 1,
  `author_id` int(10) unsigned DEFAULT NULL,
  `creation_ts` timestamp NOT NULL DEFAULT current_timestamp(),
  `review_requester_id` int(10) unsigned DEFAULT NULL,
  `review_request_ts` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `req_coverage_full_link` (`req_id`,`req_version_id`,`testcase_id`,`tcversion_id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='relation test case version ** requirement version';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `req_coverage`
--

LOCK TABLES `req_coverage` WRITE;
/*!40000 ALTER TABLE `req_coverage` DISABLE KEYS */;
INSERT INTO `req_coverage` VALUES (1,8,9,64,65,1,1,1,'2026-10-26 15:39:00',NULL,NULL),(2,16,17,64,65,1,1,1,'2026-10-26 15:39:00',NULL,NULL),(3,44,45,64,65,1,1,1,'2026-10-26 15:39:00',NULL,NULL),(4,8,9,70,71,1,1,1,'2026-10-26 15:39:00',NULL,NULL),(5,16,17,70,71,1,1,1,'2026-10-26 15:39:00',NULL,NULL),(6,4,5,74,75,1,1,1,'2026-10-26 15:39:00',NULL,NULL),(7,6,7,78,79,1,1,1,'2026-10-26 15:39:00',NULL,NULL),(8,6,7,81,82,1,1,1,'2026-10-26 15:39:00',NULL,NULL),(9,4,5,85,86,1,1,1,'2026-10-26 15:39:00',NULL,NULL),(10,18,19,88,89,1,1,1,'2026-10-26 15:39:00',NULL,NULL),(11,16,17,92,93,1,1,1,'2026-10-26 15:39:00',NULL,NULL),(12,10,11,98,99,1,1,1,'2026-10-26 15:39:01',NULL,NULL),(13,44,45,98,99,1,1,1,'2026-10-26 15:39:01',NULL,NULL),(14,10,11,104,105,1,1,1,'2026-10-26 15:39:01',NULL,NULL),(15,44,45,104,105,1,1,1,'2026-10-26 15:39:01',NULL,NULL),(16,10,11,109,110,1,1,1,'2026-10-26 15:39:01',NULL,NULL),(17,12,13,114,115,1,1,1,'2026-10-26 15:39:01',NULL,NULL),(18,14,15,121,122,1,1,1,'2026-10-26 15:39:01',NULL,NULL),(19,14,15,126,127,1,1,1,'2026-10-26 15:39:01',NULL,NULL),(20,10,11,130,131,1,1,1,'2026-10-26 15:39:01',NULL,NULL),(21,12,13,130,131,1,1,1,'2026-10-26 15:39:01',NULL,NULL),(22,24,25,135,136,1,1,1,'2026-10-26 15:39:01',NULL,NULL),(23,40,41,135,136,1,1,1,'2026-10-26 15:39:01',NULL,NULL),(24,22,23,140,141,1,1,1,'2026-10-26 15:39:01',NULL,NULL),(25,22,23,147,148,1,1,1,'2026-10-26 15:39:01',NULL,NULL),(26,22,23,153,154,1,1,1,'2026-10-26 15:39:02',NULL,NULL),(27,26,27,158,159,1,1,1,'2026-10-26 15:39:02',NULL,NULL),(28,32,33,163,164,1,1,1,'2026-10-26 15:39:02',NULL,NULL),(29,26,27,163,164,1,1,1,'2026-10-26 15:39:02',NULL,NULL),(30,32,33,167,168,1,1,1,'2026-10-26 15:39:02',NULL,NULL),(31,28,29,172,173,1,1,1,'2026-10-26 15:39:02',NULL,NULL),(32,28,29,176,177,1,1,1,'2026-10-26 15:39:02',NULL,NULL),(33,30,31,180,181,1,1,1,'2026-10-26 15:39:02',NULL,NULL),(34,34,35,180,181,1,1,1,'2026-10-26 15:39:02',NULL,NULL),(35,30,31,184,185,1,1,1,'2026-10-26 15:39:02',NULL,NULL),(36,28,29,188,189,1,1,1,'2026-10-26 15:39:02',NULL,NULL),(37,30,31,188,189,1,1,1,'2026-10-26 15:39:02',NULL,NULL),(38,36,37,195,196,1,1,1,'2026-10-26 15:39:02',NULL,NULL),(39,34,35,202,203,1,1,1,'2026-10-26 15:39:02',NULL,NULL),(40,34,35,207,208,1,1,1,'2026-10-26 15:39:03',NULL,NULL),(41,38,39,214,215,1,1,1,'2026-10-26 15:39:03',NULL,NULL),(42,40,41,219,220,1,1,1,'2026-10-26 15:39:03',NULL,NULL),(43,46,47,224,225,1,1,1,'2026-10-26 15:39:03',NULL,NULL),(44,48,49,230,231,1,1,1,'2026-10-26 15:39:03',NULL,NULL),(45,50,51,234,235,1,1,1,'2026-10-26 15:39:03',NULL,NULL),(46,10,11,234,235,1,1,1,'2026-10-26 15:39:03',NULL,NULL),(47,52,53,238,239,1,1,1,'2026-10-26 15:39:03',NULL,NULL),(48,54,55,242,243,1,1,1,'2026-10-26 15:39:03',NULL,NULL),(49,60,61,246,247,1,1,1,'2026-10-26 15:39:03',NULL,NULL),(50,56,57,252,253,1,1,1,'2026-10-26 15:39:03',NULL,NULL),(51,56,57,255,256,1,1,1,'2026-10-26 15:39:03',NULL,NULL),(52,58,59,260,261,1,1,1,'2026-10-26 15:39:04',NULL,NULL);
/*!40000 ALTER TABLE `req_coverage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `req_monitor`
--

DROP TABLE IF EXISTS `req_monitor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `req_monitor` (
  `req_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `testproject_id` int(11) NOT NULL,
  PRIMARY KEY (`req_id`,`user_id`,`testproject_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `req_monitor`
--

LOCK TABLES `req_monitor` WRITE;
/*!40000 ALTER TABLE `req_monitor` DISABLE KEYS */;
/*!40000 ALTER TABLE `req_monitor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `req_relations`
--

DROP TABLE IF EXISTS `req_relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `req_relations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `source_id` int(10) unsigned NOT NULL,
  `destination_id` int(10) unsigned NOT NULL,
  `relation_type` smallint(5) unsigned NOT NULL DEFAULT 1,
  `author_id` int(10) unsigned DEFAULT NULL,
  `creation_ts` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `req_relations`
--

LOCK TABLES `req_relations` WRITE;
/*!40000 ALTER TABLE `req_relations` DISABLE KEYS */;
/*!40000 ALTER TABLE `req_relations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `req_revisions`
--

DROP TABLE IF EXISTS `req_revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `req_revisions` (
  `parent_id` int(10) unsigned NOT NULL,
  `id` int(10) unsigned NOT NULL,
  `revision` smallint(5) unsigned NOT NULL DEFAULT 1,
  `req_doc_id` varchar(64) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `scope` text DEFAULT NULL,
  `status` char(1) NOT NULL DEFAULT 'V',
  `type` char(1) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `is_open` tinyint(1) NOT NULL DEFAULT 1,
  `expected_coverage` int(10) NOT NULL DEFAULT 1,
  `log_message` text DEFAULT NULL,
  `author_id` int(10) unsigned DEFAULT NULL,
  `creation_ts` timestamp NOT NULL DEFAULT current_timestamp(),
  `modifier_id` int(10) unsigned DEFAULT NULL,
  `modification_ts` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `req_revisions_uidx1` (`parent_id`,`revision`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `req_revisions`
--

LOCK TABLES `req_revisions` WRITE;
/*!40000 ALTER TABLE `req_revisions` DISABLE KEYS */;
/*!40000 ALTER TABLE `req_revisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `req_specs`
--

DROP TABLE IF EXISTS `req_specs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `req_specs` (
  `id` int(10) unsigned NOT NULL,
  `testproject_id` int(10) unsigned NOT NULL,
  `doc_id` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `req_spec_uk1` (`doc_id`,`testproject_id`),
  KEY `testproject_id` (`testproject_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Dev. Documents (e.g. System Requirements Specification)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `req_specs`
--

LOCK TABLES `req_specs` WRITE;
/*!40000 ALTER TABLE `req_specs` DISABLE KEYS */;
INSERT INTO `req_specs` VALUES (20,1,'SRS-R-ART'),(42,1,'SRS-R-NOT'),(2,1,'SRS-R-SHR');
/*!40000 ALTER TABLE `req_specs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `req_specs_revisions`
--

DROP TABLE IF EXISTS `req_specs_revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `req_specs_revisions` (
  `parent_id` int(10) unsigned NOT NULL,
  `id` int(10) unsigned NOT NULL,
  `revision` smallint(5) unsigned NOT NULL DEFAULT 1,
  `doc_id` varchar(64) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `scope` text DEFAULT NULL,
  `total_req` int(10) NOT NULL DEFAULT 0,
  `status` int(10) unsigned DEFAULT 1,
  `type` char(1) DEFAULT NULL,
  `log_message` text DEFAULT NULL,
  `author_id` int(10) unsigned DEFAULT NULL,
  `creation_ts` timestamp NOT NULL DEFAULT current_timestamp(),
  `modifier_id` int(10) unsigned DEFAULT NULL,
  `modification_ts` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `req_specs_revisions_uidx1` (`parent_id`,`revision`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `req_specs_revisions`
--

LOCK TABLES `req_specs_revisions` WRITE;
/*!40000 ALTER TABLE `req_specs_revisions` DISABLE KEYS */;
INSERT INTO `req_specs_revisions` VALUES (2,3,1,'SRS-R-SHR','UC-S4-001 Course Sharing & Permissions','<p>Course owner shares a course with other students as VIEWER or CONTRIBUTOR. Source: UniShare_Iteration_4.md Use Case Diagram 1 + Use Case 1; src/server/api/routers/course.ts (inviteCollaborator, acceptInvitation, rejectInvitation, getPendingInvitations); resource.ts.</p>',0,1,'2','Requirement Specification Created',1,'2026-10-26 15:38:59',NULL,'2026-10-26 15:38:59'),(20,21,1,'SRS-R-ART','UC-S4-003 Public Articles','<p>Students write articles that move DRAFT -&gt; PUBLISHED -&gt; ARCHIVED and are readable publicly. Source: UniShare_Iteration_4.md Use Case Diagram 3 + Use Case 3; src/server/api/routers/article.ts; src/app/(student)/my-articles, src/app/articles.</p>',0,1,'2','Requirement Specification Created',1,'2026-10-26 15:38:59',NULL,'2026-10-26 15:38:59'),(42,43,1,'SRS-R-NOT','UC-S4-004 Notifications','<p>In-app notifications with unread badge and user preferences. Source: UniShare_Iteration_4.md Use Case Diagram 4 + Use Case 4; src/server/api/routers/notification.ts; src/components/notification-bell.tsx; src/app/(student)/settings/page.tsx.</p>',0,1,'2','Requirement Specification Created',1,'2026-10-26 15:38:59',NULL,'2026-10-26 15:38:59');
/*!40000 ALTER TABLE `req_specs_revisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `req_versions`
--

DROP TABLE IF EXISTS `req_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `req_versions` (
  `id` int(10) unsigned NOT NULL,
  `version` smallint(5) unsigned NOT NULL DEFAULT 1,
  `revision` smallint(5) unsigned NOT NULL DEFAULT 1,
  `scope` text DEFAULT NULL,
  `status` char(1) NOT NULL DEFAULT 'V',
  `type` char(1) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `is_open` tinyint(1) NOT NULL DEFAULT 1,
  `expected_coverage` int(10) NOT NULL DEFAULT 1,
  `author_id` int(10) unsigned DEFAULT NULL,
  `creation_ts` timestamp NOT NULL DEFAULT current_timestamp(),
  `modifier_id` int(10) unsigned DEFAULT NULL,
  `modification_ts` datetime NOT NULL DEFAULT current_timestamp(),
  `log_message` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `req_versions`
--

LOCK TABLES `req_versions` WRITE;
/*!40000 ALTER TABLE `req_versions` DISABLE KEYS */;
INSERT INTO `req_versions` VALUES (5,1,1,'<p>The system shall allow only the student who created a course to invite collaborators. Any other user shall receive &#x27;Only the owner can invite collaborators&#x27;. Inviting to a non-existent course shall return &#x27;Course not found&#x27;.</p>','V','3',1,1,1,1,'2026-10-26 15:38:59',NULL,'2026-10-26 15:38:59','Requirement Created'),(7,1,1,'<p>The system shall reject an invitation to the owner himself (&#x27;You can&#x27;t invite yourself&#x27;) and a second invitation to a user already invited to the same course (&#x27;User already invited&#x27;).</p>','V','3',1,1,1,1,'2026-10-26 15:38:59',NULL,'2026-10-26 15:38:59','Requirement Created'),(9,1,1,'<p>The owner shall choose exactly one permission level, VIEWER or CONTRIBUTOR. A new invitation is stored with status PENDING and the invitee receives a COURSE_INVITATION notification &#x27;&lt;owner&gt; invited you to collaborate on &lt;course&gt;&#x27;.</p>','V','3',1,1,1,1,'2026-10-26 15:38:59',NULL,'2026-10-26 15:38:59','Requirement Created'),(11,1,1,'<p>The invitee shall see pending invitations under Settings &gt; Pending Invitations and can Accept or Decline. Accept sets status ACCEPTED and joinedAt and the course appears in the invitee&#x27;s course list; Decline sets REJECTED. The owner receives &#x27;Invitation accepted&#x27; / &#x27;Invitation declined&#x27;. Only PENDING invitations can be answered.</p>','V','3',1,1,1,1,'2026-10-26 15:38:59',NULL,'2026-10-26 15:38:59','Requirement Created'),(13,1,1,'<p>A VIEWER collaborator can open the shared course, view all resource cards and download files but cannot add, edit or delete resources or upload files.</p>','V','3',1,1,1,1,'2026-10-26 15:38:59',NULL,'2026-10-26 15:38:59','Requirement Created'),(15,1,1,'<p>A CONTRIBUTOR can add/update resources and upload files to cards that allow uploads, but cannot delete resources (&#x27;Only the course owner can delete resources&#x27;) or delete the course.</p>','V','3',1,1,1,1,'2026-10-26 15:38:59',NULL,'2026-10-26 15:38:59','Requirement Created'),(17,1,1,'<p>On Courses &gt; &lt;course&gt; &gt; Collaborators the owner can invite by email, change a collaborator&#x27;s permission (VIEWER &lt;-&gt; CONTRIBUTOR) and remove a collaborator.</p>','V','3',1,1,1,1,'2026-10-26 15:38:59',NULL,'2026-10-26 15:38:59','Requirement Created'),(19,1,1,'<p>The system shall validate that the invited student belongs to the same faculty as the owner (Iteration 4: &#x27;System validates student is in same faculty&#x27;).</p>','V','3',1,1,1,1,'2026-10-26 15:38:59',NULL,'2026-10-26 15:38:59','Requirement Created'),(23,1,1,'<p>Title is mandatory, 1 to 200 characters; Excerpt optional, max 500 characters; Cover image optional and must be a valid URL; Tags optional, comma-separated. Empty title shows &#x27;Please enter a title for your article&#x27;.</p>','V','3',1,1,1,1,'2026-10-26 15:38:59',NULL,'2026-10-26 15:38:59','Requirement Created'),(25,1,1,'<p>Saving a new article stores it with status DRAFT, the author as current user, an estimated read time (words/200, rounded up) and shows &#x27;Article saved as draft&#x27;.</p>','V','3',1,1,1,1,'2026-10-26 15:38:59',NULL,'2026-10-26 15:38:59','Requirement Created'),(27,1,1,'<p>The slug is generated from the title (lower-case, punctuation removed, spaces -&gt; &#x27;-&#x27;). If the slug exists the system appends -1, -2, ... On title change the slug is regenerated.</p>','V','3',1,1,1,1,'2026-10-26 15:38:59',NULL,'2026-10-26 15:38:59','Requirement Created'),(29,1,1,'<p>Only the author can publish, and only a DRAFT article can be published (&#x27;Only draft articles can be published&#x27;). Publishing sets PUBLISHED and publishedAt and shows &#x27;Article published!&#x27;.</p>','V','3',1,1,1,1,'2026-10-26 15:38:59',NULL,'2026-10-26 15:38:59','Requirement Created'),(31,1,1,'<p>Only the author can archive (&#x27;Article archived&#x27;) or delete (&#x27;Article deleted successfully&#x27;) an article; other users get &#x27;You can only archive/delete your own articles&#x27;.</p>','V','3',1,1,1,1,'2026-10-26 15:38:59',NULL,'2026-10-26 15:38:59','Requirement Created'),(33,1,1,'<p>Only the author can edit an article (&#x27;You can only edit your own articles&#x27;). Saving shows &#x27;Changes saved&#x27;. Tags supplied on edit replace the previous tags.</p>','V','3',1,1,1,1,'2026-10-26 15:38:59',NULL,'2026-10-26 15:38:59','Requirement Created'),(35,1,1,'<p>The /articles page lists only PUBLISHED articles, newest publishedAt first, 12 per page by default (page size 1-50). Search matches title or excerpt case-insensitively; filter by tag; the tag list shows only tags having at least one published article.</p>','V','3',1,1,1,1,'2026-10-26 15:38:59',NULL,'2026-10-26 15:38:59','Requirement Created'),(37,1,1,'<p>A PUBLISHED article is readable by anyone, including visitors not logged in. DRAFT and ARCHIVED articles are readable only by the author; others get &#x27;This article is not published&#x27;. Unknown slug gives &#x27;Article not found&#x27;.</p>','V','3',1,1,1,1,'2026-10-26 15:38:59',NULL,'2026-10-26 15:38:59','Requirement Created'),(39,1,1,'<p>Opening a PUBLISHED article increments its view count by 1; DRAFT/ARCHIVED articles are not counted.</p>','V','3',1,1,1,1,'2026-10-26 15:38:59',NULL,'2026-10-26 15:38:59','Requirement Created'),(41,1,1,'<p>My Articles lists all of the author&#x27;s articles (any status), most recently updated first, filterable by DRAFT / PUBLISHED / ARCHIVED.</p>','V','3',1,1,1,1,'2026-10-26 15:38:59',NULL,'2026-10-26 15:38:59','Requirement Created'),(45,1,1,'<p>The system shall create a notification for the recipient when a course invitation is sent (COURSE_INVITATION), accepted (INVITATION_ACCEPTED) or declined (INVITATION_REJECTED).</p>','V','3',1,1,1,1,'2026-10-26 15:38:59',NULL,'2026-10-26 15:38:59','Requirement Created'),(47,1,1,'<p>The bell icon shows the number of unread notifications; no badge at 0; values above 9 show &#x27;9+&#x27;.</p>','V','3',1,1,1,1,'2026-10-26 15:38:59',NULL,'2026-10-26 15:38:59','Requirement Created'),(49,1,1,'<p>Opening the bell lists the user&#x27;s 20 most recent notifications, newest first; with none it shows &#x27;No notifications yet&#x27;.</p>','V','3',1,1,1,1,'2026-10-26 15:38:59',NULL,'2026-10-26 15:38:59','Requirement Created'),(51,1,1,'<p>Clicking a notification marks it read and decreases the badge by 1. A course/timetable invitation notification opens Settings &gt; Pending Invitations (/settings?tab=invitations).</p>','V','3',1,1,1,1,'2026-10-26 15:38:59',NULL,'2026-10-26 15:38:59','Requirement Created'),(53,1,1,'<p>&#x27;Mark all as read&#x27; sets every unread notification of the user to read; badge disappears.</p>','V','3',1,1,1,1,'2026-10-26 15:38:59',NULL,'2026-10-26 15:38:59','Requirement Created'),(55,1,1,'<p>A user can only list, count and mark his own notifications; another user&#x27;s notification id gives &#x27;Notification not found&#x27;.</p>','V','3',1,1,1,1,'2026-10-26 15:38:59',NULL,'2026-10-26 15:38:59','Requirement Created'),(57,1,1,'<p>Settings &gt; Notification Preferences lets the user switch in-app and email notifications on/off for Class reminders, Collaboration invites, Audit log alerts and System notifications. Defaults are created on first visit; saved values persist after reload.</p>','V','3',1,1,1,1,'2026-10-26 15:38:59',NULL,'2026-10-26 15:38:59','Requirement Created'),(59,1,1,'<p>Class reminder timing accepts 5 to 30 minutes before class; the UI offers 5, 10, 15 and 30.</p>','V','3',1,1,1,1,'2026-10-26 15:38:59',NULL,'2026-10-26 15:38:59','Requirement Created'),(61,1,1,'<p>&#x27;View all&#x27; opens the full notification list, paginated (page size 1-100, default 20).</p>','V','3',1,1,1,1,'2026-10-26 15:38:59',NULL,'2026-10-26 15:38:59','Requirement Created');
/*!40000 ALTER TABLE `req_versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reqmgrsystems`
--

DROP TABLE IF EXISTS `reqmgrsystems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `reqmgrsystems` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `type` int(10) DEFAULT 0,
  `cfg` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `reqmgrsystems_uidx1` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reqmgrsystems`
--

LOCK TABLES `reqmgrsystems` WRITE;
/*!40000 ALTER TABLE `reqmgrsystems` DISABLE KEYS */;
/*!40000 ALTER TABLE `reqmgrsystems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `requirements`
--

DROP TABLE IF EXISTS `requirements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `requirements` (
  `id` int(10) unsigned NOT NULL,
  `srs_id` int(10) unsigned NOT NULL,
  `req_doc_id` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `requirements_req_doc_id` (`srs_id`,`req_doc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `requirements`
--

LOCK TABLES `requirements` WRITE;
/*!40000 ALTER TABLE `requirements` DISABLE KEYS */;
INSERT INTO `requirements` VALUES (4,2,'REQ-SHR-01'),(6,2,'REQ-SHR-02'),(8,2,'REQ-SHR-03'),(10,2,'REQ-SHR-04'),(12,2,'REQ-SHR-05'),(14,2,'REQ-SHR-06'),(16,2,'REQ-SHR-07'),(18,2,'REQ-SHR-08'),(22,20,'REQ-ART-01'),(24,20,'REQ-ART-02'),(26,20,'REQ-ART-03'),(28,20,'REQ-ART-04'),(30,20,'REQ-ART-05'),(32,20,'REQ-ART-06'),(34,20,'REQ-ART-07'),(36,20,'REQ-ART-08'),(38,20,'REQ-ART-09'),(40,20,'REQ-ART-10'),(44,42,'REQ-NOT-01'),(46,42,'REQ-NOT-02'),(48,42,'REQ-NOT-03'),(50,42,'REQ-NOT-04'),(52,42,'REQ-NOT-05'),(54,42,'REQ-NOT-06'),(56,42,'REQ-NOT-07'),(58,42,'REQ-NOT-08'),(60,42,'REQ-NOT-09');
/*!40000 ALTER TABLE `requirements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rights`
--

DROP TABLE IF EXISTS `rights`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `rights` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `description` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `rights_descr` (`description`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rights`
--

LOCK TABLES `rights` WRITE;
/*!40000 ALTER TABLE `rights` DISABLE KEYS */;
INSERT INTO `rights` VALUES (53,'cfield_assignment'),(18,'cfield_management'),(17,'cfield_view'),(51,'codetracker_management'),(52,'codetracker_view'),(56,'delete_frozen_tcversion'),(22,'events_mgt'),(54,'exec_assign_testcases'),(36,'exec_delete'),(35,'exec_edit_notes'),(49,'exec_ro_access'),(41,'exec_testcases_assigned_to_me'),(31,'issuetracker_management'),(32,'issuetracker_view'),(29,'keyword_assignment'),(9,'mgt_modify_key'),(12,'mgt_modify_product'),(11,'mgt_modify_req'),(7,'mgt_modify_tc'),(48,'mgt_plugins'),(16,'mgt_testplan_create'),(30,'mgt_unfreeze_req'),(13,'mgt_users'),(20,'mgt_view_events'),(8,'mgt_view_key'),(10,'mgt_view_req'),(6,'mgt_view_tc'),(21,'mgt_view_usergroups'),(50,'monitor_requirement'),(24,'platform_management'),(25,'platform_view'),(26,'project_inventory_management'),(27,'project_inventory_view'),(33,'reqmgrsystem_management'),(34,'reqmgrsystem_view'),(28,'req_tcase_link_management'),(14,'role_management'),(19,'system_configuration'),(47,'testcase_freeze'),(43,'testplan_add_remove_platforms'),(2,'testplan_create_build'),(1,'testplan_execute'),(3,'testplan_metrics'),(40,'testplan_milestone_overview'),(4,'testplan_planning'),(45,'testplan_set_urgent_testcases'),(46,'testplan_show_testcases_newest_versions'),(37,'testplan_unlink_executed_testcases'),(44,'testplan_update_linked_testcase_versions'),(5,'testplan_user_role_assignment'),(55,'testproject_add_remove_keywords_executed_tcversions'),(38,'testproject_delete_executed_testcases'),(39,'testproject_edit_executed_testcases'),(42,'testproject_metrics_dashboard'),(23,'testproject_user_role_assignment'),(15,'user_role_assignment');
/*!40000 ALTER TABLE `rights` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `risk_assignments`
--

DROP TABLE IF EXISTS `risk_assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `risk_assignments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `testplan_id` int(10) unsigned NOT NULL DEFAULT 0,
  `node_id` int(10) unsigned NOT NULL DEFAULT 0,
  `risk` char(1) NOT NULL DEFAULT '2',
  `importance` char(1) NOT NULL DEFAULT 'M',
  PRIMARY KEY (`id`),
  UNIQUE KEY `risk_assignments_tplan_node_id` (`testplan_id`,`node_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `risk_assignments`
--

LOCK TABLES `risk_assignments` WRITE;
/*!40000 ALTER TABLE `risk_assignments` DISABLE KEYS */;
/*!40000 ALTER TABLE `risk_assignments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_rights`
--

DROP TABLE IF EXISTS `role_rights`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_rights` (
  `role_id` int(10) NOT NULL DEFAULT 0,
  `right_id` int(10) NOT NULL DEFAULT 0,
  PRIMARY KEY (`role_id`,`right_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_rights`
--

LOCK TABLES `role_rights` WRITE;
/*!40000 ALTER TABLE `role_rights` DISABLE KEYS */;
INSERT INTO `role_rights` VALUES (4,3),(4,6),(4,7),(4,8),(4,9),(4,10),(4,11),(4,28),(4,29),(4,30),(4,50),(5,3),(5,6),(5,8),(6,1),(6,2),(6,3),(6,6),(6,7),(6,8),(6,9),(6,11),(6,25),(6,27),(6,28),(6,29),(6,30),(6,50),(7,1),(7,3),(7,6),(7,8),(8,1),(8,2),(8,3),(8,4),(8,5),(8,6),(8,7),(8,8),(8,9),(8,10),(8,11),(8,12),(8,13),(8,14),(8,15),(8,16),(8,17),(8,18),(8,19),(8,20),(8,21),(8,22),(8,23),(8,24),(8,25),(8,26),(8,27),(8,28),(8,29),(8,30),(8,31),(8,32),(8,33),(8,34),(8,35),(8,36),(8,37),(8,38),(8,39),(8,40),(8,41),(8,42),(8,43),(8,44),(8,45),(8,46),(8,47),(8,48),(8,50),(8,51),(8,52),(8,53),(8,54),(9,1),(9,2),(9,3),(9,4),(9,5),(9,6),(9,7),(9,8),(9,9),(9,10),(9,11),(9,15),(9,16),(9,24),(9,25),(9,26),(9,27),(9,28),(9,29),(9,30),(9,47),(9,50);
/*!40000 ALTER TABLE `role_rights` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `description` varchar(100) NOT NULL DEFAULT '',
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_rights_roles_descr` (`description`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'<reserved system role 1>',NULL),(2,'<reserved system role 2>',NULL),(3,'<no rights>',NULL),(4,'test designer',NULL),(5,'guest',NULL),(6,'senior tester',NULL),(7,'tester',NULL),(8,'admin',NULL),(9,'leader',NULL);
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tcsteps`
--

DROP TABLE IF EXISTS `tcsteps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tcsteps` (
  `id` int(10) unsigned NOT NULL,
  `step_number` int(11) NOT NULL DEFAULT 1,
  `actions` text DEFAULT NULL,
  `expected_results` text DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `execution_type` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1 -> manual, 2 -> automated',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tcsteps`
--

LOCK TABLES `tcsteps` WRITE;
/*!40000 ALTER TABLE `tcsteps` DISABLE KEYS */;
INSERT INTO `tcsteps` VALUES (66,1,'<p>Open Courses &gt; SECJ3343 Software Quality Assurance &gt; Collaborators.</p>','<p>Collaborators page shows &#x27;Manage who has access to SECJ3343 Software Quality Assurance&#x27;.</p>',1,1),(67,2,'<p>Enter Student B&#x27;s email in the invite field (colleague@university.edu placeholder).</p>','<p>Email accepted in the field.</p>',1,1),(68,3,'<p>Select permission &#x27;Viewer&#x27; and click Invite.</p>','<p>Success message shown; Student B listed with role Viewer and status Pending.</p>',1,1),(69,4,'<p>Log in as Student B and open the notification bell.</p>','<p>Notification &#x27;New course invitation&#x27;: &#x27;Student A invited you to collaborate on SECJ3343 Software Quality Assurance&#x27;.</p>',1,1),(72,1,'<p>On the Collaborators page enter Student B&#x27;s email, select &#x27;Contributor&#x27;, click Invite.</p>','<p>Invitation created with role Contributor, status Pending.</p>',1,1),(73,2,'<p>Log in as Student B, open Settings &gt; Pending Invitations.</p>','<p>Invitation for SECJ3343 is listed showing permission Contributor and owner Student A.</p>',1,1),(76,1,'<p>Log in as Student B, open SECJ3343 &gt; Collaborators.</p>','<p>Invite controls are hidden or disabled for a non-owner.</p>',1,1),(77,2,'<p>As Student B send an invite request for Student C to SECJ3343 (e.g. via the API course.inviteCollaborator).</p>','<p>Request rejected with FORBIDDEN &#x27;Only the owner can invite collaborators&#x27;; no invitation created.</p>',1,1),(80,1,'<p>On the Collaborators page enter Student A&#x27;s own email, choose Viewer, click Invite.</p>','<p>Error &#x27;You can&#x27;t invite yourself&#x27;; no collaborator row added.</p>',1,1),(83,1,'<p>Invite Student B again to SECJ3343 as Contributor.</p>','<p>Error &#x27;User already invited&#x27;; existing invitation unchanged (role and status not modified).</p>',1,1),(84,2,'<p>Repeat with Student B&#x27;s invitation in ACCEPTED status.</p>','<p>Same error &#x27;User already invited&#x27;.</p>',1,1),(87,1,'<p>Call course.inviteCollaborator with courseId &#x27;does-not-exist&#x27;, a valid user id and role VIEWER.</p>','<p>NOT_FOUND &#x27;Course not found&#x27;; nothing stored.</p>',1,1),(90,1,'<p>Search/enter Student C&#x27;s email on the Collaborators page and click Invite as Viewer.</p>','<p>System refuses the invitation with a message that only students of the same faculty can be invited; no invitation or notification is created.</p>',1,1),(91,2,'<p>Invite Student B (same faculty) the same way.</p>','<p>Invitation created (valid partition) - confirms the rule is faculty based.</p>',1,1),(94,1,'<p>As Student A open Collaborators, change Student B&#x27;s role to Contributor and save.</p>','<p>Student B shown as Contributor; Student B can now add a resource (see TS-R3).</p>',1,1),(95,2,'<p>Change Student B back to Viewer.</p>','<p>Role shown as Viewer; Student B can no longer add resources.</p>',1,1),(96,3,'<p>Click Remove for Student B and confirm.</p>','<p>Student B disappears from the list; SECJ3343 no longer appears in Student B&#x27;s courses.</p>',1,1),(100,1,'<p>Log in as Student B, open Settings &gt; Pending Invitations.</p>','<p>Invitation listed with course title, owner name and permission Viewer.</p>',1,1),(101,2,'<p>Click Accept.</p>','<p>Invitation removed from Pending Invitations; success message shown.</p>',1,1),(102,3,'<p>Open Courses.</p>','<p>SECJ3343 Software Quality Assurance is listed as a shared course with role Viewer.</p>',1,1),(103,4,'<p>Log in as Student A and open the bell.</p>','<p>Notification &#x27;Invitation accepted&#x27;: &#x27;Student B accepted your invitation to SECJ3343 Software Quality Assurance&#x27;.</p>',1,1),(106,1,'<p>As Student B open Settings &gt; Pending Invitations and click Decline.</p>','<p>Invitation removed from the list; when none remain &#x27;No pending invitations&#x27; is shown.</p>',1,1),(107,2,'<p>Open Courses as Student B.</p>','<p>SECJ3343 is NOT listed.</p>',1,1),(108,3,'<p>As Student A open the bell.</p>','<p>Notification &#x27;Invitation declined&#x27;: &#x27;Student B declined your invitation to SECJ3343 Software Quality Assurance&#x27;.</p>',1,1),(111,1,'<p>Call course.acceptInvitation for SECJ3343 again as Student B.</p>','<p>Request fails (record not found for status PENDING); status stays ACCEPTED, joinedAt unchanged, no new notification to owner.</p>',1,1),(112,2,'<p>Call course.rejectInvitation for SECJ3343 as Student B.</p>','<p>Request fails; status stays ACCEPTED.</p>',1,1),(116,1,'<p>Log in as Student B and open SECJ3343.</p>','<p>Course and all resource cards are displayed.</p>',1,1),(117,2,'<p>Download week1.pdf from &#x27;Lecture Slides&#x27;.</p>','<p>File downloads successfully.</p>',1,1),(118,3,'<p>Look for Add resource / Upload / Edit / Delete controls.</p>','<p>Controls are not shown (read-only view).</p>',1,1),(119,4,'<p>Attempt resource.create on SECJ3343 via API as Student B.</p>','<p>FORBIDDEN &#x27;Only course owner and contributors can create resources&#x27;.</p>',1,1),(120,5,'<p>Attempt to upload a file to &#x27;Lecture Slides&#x27; via API as Student B.</p>','<p>FORBIDDEN &#x27;You don&#x27;t have permission to add files to this resource&#x27;.</p>',1,1),(123,1,'<p>As Student B open SECJ3343 and add resource card &#x27;Tutorial 1&#x27;.</p>','<p>Card created and visible to Student A as well.</p>',1,1),(124,2,'<p>Upload tutorial1.pdf (2 MB) into &#x27;Lecture Slides&#x27;.</p>','<p>File uploaded and listed in the card.</p>',1,1),(125,3,'<p>Edit the title of &#x27;Tutorial 1&#x27; to &#x27;Tutorial 1 - BVA&#x27;.</p>','<p>Change saved.</p>',1,1),(128,1,'<p>As Student B try to delete resource &#x27;Lecture Slides&#x27;.</p>','<p>Delete control hidden; API call returns FORBIDDEN &#x27;Only the course owner can delete resources&#x27;. Resource still exists.</p>',1,1),(129,2,'<p>As Student B open SECJ3343 &gt; Settings and try &#x27;Delete course&#x27;.</p>','<p>Not allowed; course still exists.</p>',1,1),(132,1,'<p>As Student C open /courses/&lt;SECJ3343 id&gt; directly.</p>','<p>Access denied / course not found; no resources shown.</p>',1,1),(133,2,'<p>As Student B (rejected) open the same URL.</p>','<p>Access denied.</p>',1,1),(137,1,'<p>Open My Articles &gt; New Article.</p>','<p>Form shows Title*, Excerpt (Optional), Cover Image (Optional), Tags (Optional), Content.</p>',1,1),(138,2,'<p>Title &#x27;Intro to Boundary Value Analysis&#x27;, Excerpt &#x27;Short guide to BVA&#x27;, Tags &#x27;Testing, QA&#x27;, some content; click Save Draft.</p>','<p>Toast &#x27;Article saved as draft&#x27;.</p>',1,1),(139,3,'<p>Open My Articles.</p>','<p>Article listed with status DRAFT, tags Testing and QA, read time &gt;= 1 min.</p>',1,1),(142,1,'<p>Leave Title empty (0 chars), click Save Draft.</p>','<p>Error &#x27;Please enter a title for your article&#x27;; nothing saved.</p>',1,1),(143,2,'<p>Title = &#x27;A&#x27; (1 char), Save Draft.</p>','<p>Saved as draft.</p>',1,1),(144,3,'<p>Title = 200 x &#x27;a&#x27;, Save Draft.</p>','<p>Saved as draft.</p>',1,1),(145,4,'<p>Title = 201 x &#x27;a&#x27;, Save Draft.</p>','<p>Rejected with validation error (max 200); nothing saved.</p>',1,1),(146,5,'<p>Title = 5 spaces only.</p>','<p>Treated as empty: &#x27;Please enter a title for your article&#x27;.</p>',1,1),(149,1,'<p>Leave Excerpt empty and save.</p>','<p>Saved (excerpt optional).</p>',1,1),(150,2,'<p>Excerpt = 499 characters, save.</p>','<p>Saved.</p>',1,1),(151,3,'<p>Excerpt = 500 characters, save.</p>','<p>Saved.</p>',1,1),(152,4,'<p>Excerpt = 501 characters, save.</p>','<p>Validation error (max 500); not saved.</p>',1,1),(155,1,'<p>Cover image = https://utfs.io/f/cover.png, save.</p>','<p>Saved; cover shown on article card.</p>',1,1),(156,2,'<p>Cover image = &#x27;not a url&#x27;, save via API article.create.</p>','<p>Validation error (invalid url); not saved.</p>',1,1),(157,3,'<p>Cover image empty, save.</p>','<p>Saved without cover (optional).</p>',1,1),(160,1,'<p>Create article &#x27;Software Testing 101!&#x27; and publish.</p>','<p>URL is /articles/software-testing-101 (punctuation removed, lower-case, dashes).</p>',1,1),(161,2,'<p>Create a second article with the same title and publish.</p>','<p>URL is /articles/software-testing-101-1.</p>',1,1),(162,3,'<p>Create a third one.</p>','<p>URL is /articles/software-testing-101-2.</p>',1,1),(165,1,'<p>Open My Articles &gt; Edit; change title to &#x27;BVA Explained&#x27;, tags to &#x27;Testing&#x27;; Save.</p>','<p>Toast &#x27;Changes saved&#x27;.</p>',1,1),(166,2,'<p>Re-open the article.</p>','<p>Title &#x27;BVA Explained&#x27;, slug &#x27;bva-explained&#x27;, only tag Testing (QA removed).</p>',1,1),(169,1,'<p>As Student B open /my-articles/&lt;A&#x27;s article id&gt;/edit.</p>','<p>Edit not possible / redirected; no form for A&#x27;s article.</p>',1,1),(170,2,'<p>Call article.update for that id with a new title as Student B.</p>','<p>FORBIDDEN &#x27;You can only edit your own articles&#x27;; article unchanged.</p>',1,1),(174,1,'<p>In My Articles click Publish on &#x27;BVA Explained&#x27;.</p>','<p>Toast &#x27;Article published!&#x27;; status PUBLISHED, published date = today.</p>',1,1),(175,2,'<p>Log out and open /articles.</p>','<p>&#x27;BVA Explained&#x27; appears first in the list.</p>',1,1),(178,1,'<p>Call article.publish on the PUBLISHED article.</p>','<p>BAD_REQUEST &#x27;Only draft articles can be published&#x27;; publishedAt unchanged.</p>',1,1),(179,2,'<p>Call article.publish on the ARCHIVED article.</p>','<p>BAD_REQUEST &#x27;Only draft articles can be published&#x27;; status stays ARCHIVED.</p>',1,1),(182,1,'<p>Open the article as Student A and choose Archive.</p>','<p>Toast &#x27;Article archived&#x27;; status ARCHIVED.</p>',1,1),(183,2,'<p>Open /articles as a visitor.</p>','<p>&#x27;BVA Explained&#x27; no longer listed.</p>',1,1),(186,1,'<p>Open the article and choose Delete, confirm.</p>','<p>Toast &#x27;Article deleted successfully&#x27;; redirected; article gone from My Articles.</p>',1,1),(187,2,'<p>Open its old URL /articles/delete-me.</p>','<p>&#x27;Article not found&#x27;.</p>',1,1),(190,1,'<p>As Student B call article.publish on X.</p>','<p>FORBIDDEN &#x27;You can only publish your own articles&#x27;.</p>',1,1),(191,2,'<p>As Student B call article.archive on Y.</p>','<p>FORBIDDEN &#x27;You can only archive your own articles&#x27;.</p>',1,1),(192,3,'<p>As Student B call article.delete on Y.</p>','<p>FORBIDDEN &#x27;You can only delete your own articles&#x27;; Y still exists.</p>',1,1),(193,4,'<p>As Student B open Y&#x27;s page.</p>','<p>No Edit / Archive / Delete buttons shown.</p>',1,1),(197,1,'<p>Logged out, open /articles/&lt;P slug&gt;.</p>','<p>Article P displayed.</p>',1,1),(198,2,'<p>Logged out, open /articles/&lt;D slug&gt; and /articles/&lt;R slug&gt;.</p>','<p>&#x27;This article is not published&#x27; for both.</p>',1,1),(199,3,'<p>As Student B open D and R.</p>','<p>&#x27;This article is not published&#x27;.</p>',1,1),(200,4,'<p>As Student A open D and R.</p>','<p>Both displayed with author controls.</p>',1,1),(201,5,'<p>Open /articles/no-such-slug.</p>','<p>&#x27;Article not found&#x27;.</p>',1,1),(204,1,'<p>Open /articles.</p>','<p>12 articles on page 1, newest first; no DRAFT articles.</p>',1,1),(205,2,'<p>Go to page 2.</p>','<p>Exactly 1 article (the oldest).</p>',1,1),(206,3,'<p>Call article.getAllPublished with limit 0, 1, 50, 51.</p>','<p>0 and 51 rejected by validation; 1 and 50 accepted.</p>',1,1),(209,1,'<p>Type &#x27;bva&#x27; in &#x27;Search articles by title, content, or tags...&#x27;.</p>','<p>Only &#x27;BVA Explained&#x27; shown (case-insensitive title match).</p>',1,1),(210,2,'<p>Search &#x27;BOUNDARY&#x27;.</p>','<p>&#x27;BVA Explained&#x27; shown (excerpt match).</p>',1,1),(211,3,'<p>Search &#x27;zzzz&#x27;.</p>','<p>Empty result message.</p>',1,1),(212,4,'<p>Clear search, filter by tag Testing.</p>','<p>Only &#x27;BVA Explained&#x27;.</p>',1,1),(213,5,'<p>Open the tag filter list.</p>','<p>Contains Testing and DevOps; tags used only by drafts are not listed.</p>',1,1),(216,1,'<p>Open &#x27;BVA Explained&#x27; as a visitor.</p>','<p>View count becomes 6.</p>',1,1),(217,2,'<p>Refresh once.</p>','<p>View count becomes 7.</p>',1,1),(218,3,'<p>Author opens DRAFT D.</p>','<p>View count of D stays 0.</p>',1,1),(221,1,'<p>Open My Articles (all).</p>','<p>4 articles of Student A only, most recently updated first.</p>',1,1),(222,2,'<p>Filter Draft / Published / Archived.</p>','<p>1 / 2 / 1 articles respectively; Student B&#x27;s article never shown.</p>',1,1),(226,1,'<p>Look at the bell.</p>','<p>No badge shown (0).</p>',1,1),(227,2,'<p>Generate 1 notification (Student A invites B to a course). Refresh.</p>','<p>Badge shows 1.</p>',1,1),(228,3,'<p>Generate notifications until B has 9 unread.</p>','<p>Badge shows 9.</p>',1,1),(229,4,'<p>Generate the 10th.</p>','<p>Badge shows &#x27;9+&#x27;.</p>',1,1),(232,1,'<p>Open the bell.</p>','<p>&#x27;No notifications yet&#x27;.</p>',1,1),(233,2,'<p>Create 21 notifications for B, open the bell.</p>','<p>Exactly 20 shown, newest at top; oldest (1st) not shown.</p>',1,1),(236,1,'<p>Open the bell and click &#x27;New course invitation&#x27;.</p>','<p>Navigates to /settings?tab=invitations showing the invitation.</p>',1,1),(237,2,'<p>Look at the bell.</p>','<p>Badge decreased from 3 to 2; the clicked item is shown as read.</p>',1,1),(240,1,'<p>Open the bell and click &#x27;Mark all as read&#x27;.</p>','<p>All items shown as read; badge disappears.</p>',1,1),(241,2,'<p>Reload the page.</p>','<p>Still no badge (persisted).</p>',1,1),(244,1,'<p>As Student B open the bell.</p>','<p>N is not listed; unread count excludes A&#x27;s notifications.</p>',1,1),(245,2,'<p>As Student B call notification.markAsRead with N&#x27;s id.</p>','<p>Error &#x27;Notification not found&#x27;; N stays unread for Student A.</p>',1,1),(248,1,'<p>Open the bell and click &#x27;View all&#x27;.</p>','<p>Full notification page opens (/notifications) showing the first 20 and a way to load more.</p>',1,1),(249,2,'<p>Load more.</p>','<p>Remaining 5 shown; no duplicates.</p>',1,1),(250,3,'<p>Call notification.getAll with limit 0, 1, 100, 101.</p>','<p>0 and 101 rejected; 1 and 100 accepted.</p>',1,1),(254,1,'<p>Open Settings &gt; Notification Preferences.</p>','<p>Page loads with default toggles; reminder timing shows 10 minutes.</p>',1,1),(257,1,'<p>Turn OFF email &#x27;Collaboration invites&#x27; and in-app &#x27;Audit log alerts&#x27;, keep the rest ON; Save.</p>','<p>Success message.</p>',1,1),(258,2,'<p>Reload page.</p>','<p>Exactly those two toggles are OFF.</p>',1,1),(259,3,'<p>Student A invites Student B to a course.</p>','<p>In-app notification appears; no invitation email is sent to Student B.</p>',1,1),(262,1,'<p>Open &#x27;Reminder Timing&#x27; dropdown.</p>','<p>Options 5, 10, 15, 30 minutes only.</p>',1,1),(263,2,'<p>Select 5 minutes, save, reload.</p>','<p>5 minutes persisted.</p>',1,1),(264,3,'<p>Select 30 minutes, save, reload.</p>','<p>30 minutes persisted.</p>',1,1),(265,4,'<p>Call notification.updatePreferences with classReminderMinutes 4 and 31.</p>','<p>Both rejected by validation; stored value unchanged (30).</p>',1,1);
/*!40000 ALTER TABLE `tcsteps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tcversions`
--

DROP TABLE IF EXISTS `tcversions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tcversions` (
  `id` int(10) unsigned NOT NULL,
  `tc_external_id` int(10) unsigned DEFAULT NULL,
  `version` smallint(5) unsigned NOT NULL DEFAULT 1,
  `layout` smallint(5) unsigned NOT NULL DEFAULT 1,
  `status` smallint(5) unsigned NOT NULL DEFAULT 1,
  `summary` text DEFAULT NULL,
  `preconditions` text DEFAULT NULL,
  `importance` smallint(5) unsigned NOT NULL DEFAULT 2,
  `author_id` int(10) unsigned DEFAULT NULL,
  `creation_ts` timestamp NOT NULL DEFAULT current_timestamp(),
  `updater_id` int(10) unsigned DEFAULT NULL,
  `modification_ts` datetime NOT NULL DEFAULT current_timestamp(),
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `is_open` tinyint(1) NOT NULL DEFAULT 1,
  `execution_type` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1 -> manual, 2 -> automated',
  `estimated_exec_duration` decimal(6,2) DEFAULT NULL COMMENT 'NULL will be considered as NO DATA Provided by user',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tcversions`
--

LOCK TABLES `tcversions` WRITE;
/*!40000 ALTER TABLE `tcversions` DISABLE KEYS */;
INSERT INTO `tcversions` VALUES (65,1,1,1,1,'<p>Owner invites same-faculty student as VIEWER.</p><p><b>Test design technique:</b> Use case (main flow), EP valid class</p><p><b>Requirements:</b> REQ-SHR-03, REQ-SHR-07, REQ-NOT-01</p>','<p>Student A logged in and owns course SECJ3343. Student B exists, same faculty, not yet invited.</p>',3,2,'2026-10-26 15:39:00',NULL,'2026-10-26 15:39:00',1,1,1,NULL),(71,2,1,1,1,'<p>Owner invites same-faculty student as CONTRIBUTOR.</p><p><b>Test design technique:</b> EP (role = CONTRIBUTOR partition)</p><p><b>Requirements:</b> REQ-SHR-03, REQ-SHR-07</p>','<p>Student A owns SECJ3343. Student B has no invitation for this course.</p>',3,2,'2026-10-26 15:39:00',NULL,'2026-10-26 15:39:00',1,1,1,NULL),(75,3,1,1,1,'<p>Non-owner cannot invite collaborators.</p><p><b>Test design technique:</b> DT (actor = collaborator/other student), negative</p><p><b>Requirements:</b> REQ-SHR-01</p>','<p>Student B is an ACCEPTED CONTRIBUTOR of SECJ3343 (owner Student A). Student C exists.</p>',3,2,'2026-10-26 15:39:00',NULL,'2026-10-26 15:39:00',1,1,1,NULL),(79,4,1,1,1,'<p>Owner cannot invite himself.</p><p><b>Test design technique:</b> EG / EP invalid class (invitee = owner)</p><p><b>Requirements:</b> REQ-SHR-02</p>','<p>Student A logged in, owns SECJ3343.</p>',2,2,'2026-10-26 15:39:00',NULL,'2026-10-26 15:39:00',1,1,1,NULL),(82,5,1,1,1,'<p>Duplicate invitation to the same student is rejected.</p><p><b>Test design technique:</b> EP invalid class (already invited), DT</p><p><b>Requirements:</b> REQ-SHR-02</p>','<p>Student B already has a PENDING (repeat with ACCEPTED) invitation to SECJ3343.</p>',2,2,'2026-10-26 15:39:00',NULL,'2026-10-26 15:39:00',1,1,1,NULL),(86,6,1,1,1,'<p>Invite to a course that does not exist.</p><p><b>Test design technique:</b> EG, EP invalid course id</p><p><b>Requirements:</b> REQ-SHR-01</p>','<p>Student A logged in.</p>',1,2,'2026-10-26 15:39:00',NULL,'2026-10-26 15:39:00',1,1,1,NULL),(89,7,1,1,1,'<p>Invitation to a student from a different faculty is blocked.</p><p><b>Test design technique:</b> EP (same faculty / different faculty partitions)</p><p><b>Requirements:</b> REQ-SHR-08</p>','<p>Student A (Faculty of Computing) owns SECJ3343. Student C is in Faculty of Engineering.</p>',3,2,'2026-10-26 15:39:00',NULL,'2026-10-26 15:39:00',1,1,1,NULL),(93,8,1,1,1,'<p>Owner changes collaborator permission and removes collaborator.</p><p><b>Test design technique:</b> ST (VIEWER -&gt; CONTRIBUTOR -&gt; removed)</p><p><b>Requirements:</b> REQ-SHR-07</p>','<p>Student B is ACCEPTED VIEWER on SECJ3343.</p>',2,2,'2026-10-26 15:39:00',NULL,'2026-10-26 15:39:00',1,1,1,NULL),(99,9,1,1,1,'<p>Invitee accepts a pending course invitation.</p><p><b>Test design technique:</b> ST (PENDING -&gt; ACCEPTED), use case main flow</p><p><b>Requirements:</b> REQ-SHR-04, REQ-NOT-01</p>','<p>Student B has a PENDING VIEWER invitation to SECJ3343 from Student A.</p>',3,2,'2026-10-26 15:39:00',NULL,'2026-10-26 15:39:00',1,1,1,NULL),(105,10,1,1,1,'<p>Invitee declines a pending course invitation.</p><p><b>Test design technique:</b> ST (PENDING -&gt; REJECTED)</p><p><b>Requirements:</b> REQ-SHR-04, REQ-NOT-01</p>','<p>Student B has a PENDING invitation to SECJ3343.</p>',2,2,'2026-10-26 15:39:01',NULL,'2026-10-26 15:39:01',1,1,1,NULL),(110,11,1,1,1,'<p>Answered invitation cannot be accepted or declined again.</p><p><b>Test design technique:</b> ST (invalid transition from ACCEPTED/REJECTED), EG</p><p><b>Requirements:</b> REQ-SHR-04</p>','<p>Student B&#x27;s invitation to SECJ3343 is already ACCEPTED.</p>',2,2,'2026-10-26 15:39:01',NULL,'2026-10-26 15:39:01',1,1,1,NULL),(115,12,1,1,1,'<p>VIEWER can view and download but cannot modify.</p><p><b>Test design technique:</b> DT (role = VIEWER column)</p><p><b>Requirements:</b> REQ-SHR-05</p>','<p>Student B is ACCEPTED VIEWER on SECJ3343; card &#x27;Lecture Slides&#x27; holds week1.pdf.</p>',3,2,'2026-10-26 15:39:01',NULL,'2026-10-26 15:39:01',1,1,1,NULL),(122,13,1,1,1,'<p>CONTRIBUTOR can add resources and upload files.</p><p><b>Test design technique:</b> DT (role = CONTRIBUTOR, allowed actions)</p><p><b>Requirements:</b> REQ-SHR-06</p>','<p>Student B is ACCEPTED CONTRIBUTOR on SECJ3343.</p>',3,2,'2026-10-26 15:39:01',NULL,'2026-10-26 15:39:01',1,1,1,NULL),(127,14,1,1,1,'<p>CONTRIBUTOR cannot delete resources or the course.</p><p><b>Test design technique:</b> DT (role = CONTRIBUTOR, forbidden actions)</p><p><b>Requirements:</b> REQ-SHR-06</p>','<p>Student B is ACCEPTED CONTRIBUTOR on SECJ3343.</p>',3,2,'2026-10-26 15:39:01',NULL,'2026-10-26 15:39:01',1,1,1,NULL),(131,15,1,1,1,'<p>Non-collaborator and declined user cannot open a private course.</p><p><b>Test design technique:</b> EP (no relation / REJECTED / PENDING partitions)</p><p><b>Requirements:</b> REQ-SHR-04, REQ-SHR-05</p>','<p>Student C has no relation to SECJ3343; Student B&#x27;s invitation is REJECTED.</p>',2,2,'2026-10-26 15:39:01',NULL,'2026-10-26 15:39:01',1,1,1,NULL),(136,16,1,1,1,'<p>Create article saved as draft (valid data).</p><p><b>Test design technique:</b> Use case main flow, EP valid</p><p><b>Requirements:</b> REQ-ART-02, REQ-ART-10</p>','<p>Student A logged in.</p>',3,2,'2026-10-26 15:39:01',NULL,'2026-10-26 15:39:01',1,1,1,NULL),(141,17,1,1,1,'<p>Title length boundaries (0, 1, 200, 201 characters).</p><p><b>Test design technique:</b> BVA</p><p><b>Requirements:</b> REQ-ART-01</p>','<p>Student A on My Articles &gt; New Article.</p>',3,2,'2026-10-26 15:39:01',NULL,'2026-10-26 15:39:01',1,1,1,NULL),(148,18,1,1,1,'<p>Excerpt length boundaries (500 / 501 characters).</p><p><b>Test design technique:</b> BVA</p><p><b>Requirements:</b> REQ-ART-01</p>','<p>Student A on New Article with valid title &#x27;Excerpt test&#x27;.</p>',2,2,'2026-10-26 15:39:01',NULL,'2026-10-26 15:39:01',1,1,1,NULL),(154,19,1,1,1,'<p>Cover image URL validation.</p><p><b>Test design technique:</b> EP (valid URL / invalid text / empty)</p><p><b>Requirements:</b> REQ-ART-01</p>','<p>Student A on New Article, title &#x27;Cover test&#x27;.</p>',2,2,'2026-10-26 15:39:01',NULL,'2026-10-26 15:39:01',1,1,1,NULL),(159,20,1,1,1,'<p>Duplicate titles get unique slugs.</p><p><b>Test design technique:</b> EG, EP (new slug / existing slug)</p><p><b>Requirements:</b> REQ-ART-03</p>','<p>No article with slug &#x27;software-testing-101&#x27; exists.</p>',2,2,'2026-10-26 15:39:02',NULL,'2026-10-26 15:39:02',1,1,1,NULL),(164,21,1,1,1,'<p>Author edits own article; tags are replaced.</p><p><b>Test design technique:</b> Use case alternative flow</p><p><b>Requirements:</b> REQ-ART-06, REQ-ART-03</p>','<p>Student A has DRAFT &#x27;Intro to Boundary Value Analysis&#x27; with tags Testing, QA.</p>',2,2,'2026-10-26 15:39:02',NULL,'2026-10-26 15:39:02',1,1,1,NULL),(168,22,1,1,1,'<p>User cannot edit another user&#x27;s article.</p><p><b>Test design technique:</b> DT (actor = non-author), negative</p><p><b>Requirements:</b> REQ-ART-06</p>','<p>Student A authored &#x27;BVA Explained&#x27;. Student B logged in.</p>',3,2,'2026-10-26 15:39:02',NULL,'2026-10-26 15:39:02',1,1,1,NULL),(173,23,1,1,1,'<p>Publish a draft article.</p><p><b>Test design technique:</b> ST (DRAFT -&gt; PUBLISHED)</p><p><b>Requirements:</b> REQ-ART-04</p>','<p>Student A has DRAFT &#x27;BVA Explained&#x27;.</p>',3,2,'2026-10-26 15:39:02',NULL,'2026-10-26 15:39:02',1,1,1,NULL),(177,24,1,1,1,'<p>Only DRAFT articles can be published.</p><p><b>Test design technique:</b> ST (invalid transitions PUBLISHED-&gt;PUBLISHED, ARCHIVED-&gt;PUBLISHED)</p><p><b>Requirements:</b> REQ-ART-04</p>','<p>Student A has one PUBLISHED and one ARCHIVED article.</p>',2,2,'2026-10-26 15:39:02',NULL,'2026-10-26 15:39:02',1,1,1,NULL),(181,25,1,1,1,'<p>Archive own published article.</p><p><b>Test design technique:</b> ST (PUBLISHED -&gt; ARCHIVED)</p><p><b>Requirements:</b> REQ-ART-05, REQ-ART-07</p>','<p>&#x27;BVA Explained&#x27; is PUBLISHED by Student A.</p>',2,2,'2026-10-26 15:39:02',NULL,'2026-10-26 15:39:02',1,1,1,NULL),(185,26,1,1,1,'<p>Delete own article.</p><p><b>Test design technique:</b> ST (any -&gt; deleted)</p><p><b>Requirements:</b> REQ-ART-05</p>','<p>Student A has article &#x27;Delete me&#x27; (DRAFT).</p>',2,2,'2026-10-26 15:39:02',NULL,'2026-10-26 15:39:02',1,1,1,NULL),(189,27,1,1,1,'<p>Non-author cannot publish, archive or delete.</p><p><b>Test design technique:</b> DT (actor x action), negative</p><p><b>Requirements:</b> REQ-ART-04, REQ-ART-05</p>','<p>Student A authored DRAFT X and PUBLISHED Y. Student B logged in.</p>',3,2,'2026-10-26 15:39:02',NULL,'2026-10-26 15:39:02',1,1,1,NULL),(196,28,1,1,1,'<p>Access control by status and viewer.</p><p><b>Test design technique:</b> DT (status {PUBLISHED, DRAFT, ARCHIVED} x viewer {visitor, other student, author})</p><p><b>Requirements:</b> REQ-ART-08</p>','<p>Student A has PUBLISHED P, DRAFT D, ARCHIVED R.</p>',3,2,'2026-10-26 15:39:02',NULL,'2026-10-26 15:39:02',1,1,1,NULL),(203,29,1,1,1,'<p>Listing shows only published, newest first, with pagination.</p><p><b>Test design technique:</b> EP + BVA (13 articles vs page size 12)</p><p><b>Requirements:</b> REQ-ART-07</p>','<p>Exactly 13 PUBLISHED articles (published on different times) and 2 DRAFT articles exist.</p>',2,2,'2026-10-26 15:39:02',NULL,'2026-10-26 15:39:02',1,1,1,NULL),(208,30,1,1,1,'<p>Search and tag filter.</p><p><b>Test design technique:</b> EP (title match / excerpt match / no match / case)</p><p><b>Requirements:</b> REQ-ART-07</p>','<p>Published &#x27;BVA Explained&#x27; (excerpt &#x27;boundary values&#x27;, tag Testing) and &#x27;Docker Basics&#x27; (tag DevOps).</p>',2,2,'2026-10-26 15:39:03',NULL,'2026-10-26 15:39:03',1,1,1,NULL),(215,31,1,1,1,'<p>View counter increments only for published articles.</p><p><b>Test design technique:</b> EP (published / not published)</p><p><b>Requirements:</b> REQ-ART-09</p>','<p>&#x27;BVA Explained&#x27; PUBLISHED with 5 views; DRAFT D with 0 views.</p>',1,2,'2026-10-26 15:39:03',NULL,'2026-10-26 15:39:03',1,1,1,NULL),(220,32,1,1,1,'<p>My Articles status filter.</p><p><b>Test design technique:</b> EP (filter = all / DRAFT / PUBLISHED / ARCHIVED)</p><p><b>Requirements:</b> REQ-ART-10</p>','<p>Student A has 1 DRAFT, 2 PUBLISHED, 1 ARCHIVED; Student B has 1 PUBLISHED.</p>',1,2,'2026-10-26 15:39:03',NULL,'2026-10-26 15:39:03',1,1,1,NULL),(225,33,1,1,1,'<p>Unread badge boundaries (0, 1, 9, 10).</p><p><b>Test design technique:</b> BVA</p><p><b>Requirements:</b> REQ-NOT-02</p>','<p>Student B logged in with 0 unread notifications.</p>',3,2,'2026-10-26 15:39:03',NULL,'2026-10-26 15:39:03',1,1,1,NULL),(231,34,1,1,1,'<p>Dropdown lists 20 most recent, newest first.</p><p><b>Test design technique:</b> BVA (20 / 21 notifications), EP (empty)</p><p><b>Requirements:</b> REQ-NOT-03</p>','<p>Student B has 0 notifications.</p>',2,2,'2026-10-26 15:39:03',NULL,'2026-10-26 15:39:03',1,1,1,NULL),(235,35,1,1,1,'<p>Click invitation notification marks read and opens Pending Invitations.</p><p><b>Test design technique:</b> ST (unread -&gt; read), use case</p><p><b>Requirements:</b> REQ-NOT-04, REQ-SHR-04</p>','<p>Student B has 3 unread, one of them &#x27;New course invitation&#x27;.</p>',3,2,'2026-10-26 15:39:03',NULL,'2026-10-26 15:39:03',1,1,1,NULL),(239,36,1,1,1,'<p>Mark all as read.</p><p><b>Test design technique:</b> ST (all unread -&gt; read)</p><p><b>Requirements:</b> REQ-NOT-05</p>','<p>Student B has 5 unread notifications.</p>',2,2,'2026-10-26 15:39:03',NULL,'2026-10-26 15:39:03',1,1,1,NULL),(243,37,1,1,1,'<p>User cannot read or mark another user&#x27;s notification.</p><p><b>Test design technique:</b> EG, security negative</p><p><b>Requirements:</b> REQ-NOT-06</p>','<p>Student A has notification N (id known). Student B logged in.</p>',3,2,'2026-10-26 15:39:03',NULL,'2026-10-26 15:39:03',1,1,1,NULL),(247,38,1,1,1,'<p>View all notifications page with paging.</p><p><b>Test design technique:</b> EP + BVA (limit 0, 1, 100, 101)</p><p><b>Requirements:</b> REQ-NOT-09</p>','<p>Student B has 25 notifications.</p>',2,2,'2026-10-26 15:39:03',NULL,'2026-10-26 15:39:03',1,1,1,NULL),(253,39,1,1,1,'<p>Default preferences are created on first visit.</p><p><b>Test design technique:</b> EP (new user without preferences)</p><p><b>Requirements:</b> REQ-NOT-07</p>','<p>Newly approved Student E who never opened Settings.</p>',2,2,'2026-10-26 15:39:03',NULL,'2026-10-26 15:39:03',1,1,1,NULL),(256,40,1,1,1,'<p>Save in-app / email preferences per type.</p><p><b>Test design technique:</b> DT (2 channels x 4 types)</p><p><b>Requirements:</b> REQ-NOT-07</p>','<p>Student B on Notification Preferences.</p>',2,2,'2026-10-26 15:39:03',NULL,'2026-10-26 15:39:03',1,1,1,NULL),(261,41,1,1,1,'<p>Class reminder timing boundaries.</p><p><b>Test design technique:</b> BVA (4, 5, 30, 31 minutes)</p><p><b>Requirements:</b> REQ-NOT-08</p>','<p>Student B on Notification Preferences.</p>',2,2,'2026-10-26 15:39:04',NULL,'2026-10-26 15:39:04',1,1,1,NULL);
/*!40000 ALTER TABLE `tcversions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `tcversions_without_keywords`
--

DROP TABLE IF EXISTS `tcversions_without_keywords`;
/*!50001 DROP VIEW IF EXISTS `tcversions_without_keywords`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `tcversions_without_keywords` AS SELECT
 NULL AS `testcase_id`,
 NULL AS `id` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `tcversions_without_platforms`
--

DROP TABLE IF EXISTS `tcversions_without_platforms`;
/*!50001 DROP VIEW IF EXISTS `tcversions_without_platforms`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `tcversions_without_platforms` AS SELECT
 NULL AS `testcase_id`,
 NULL AS `id` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `testcase_keywords`
--

DROP TABLE IF EXISTS `testcase_keywords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `testcase_keywords` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `testcase_id` int(10) unsigned NOT NULL DEFAULT 0,
  `tcversion_id` int(10) unsigned NOT NULL DEFAULT 0,
  `keyword_id` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx01_testcase_keywords` (`testcase_id`,`tcversion_id`,`keyword_id`),
  KEY `idx02_testcase_keywords` (`tcversion_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `testcase_keywords`
--

LOCK TABLES `testcase_keywords` WRITE;
/*!40000 ALTER TABLE `testcase_keywords` DISABLE KEYS */;
/*!40000 ALTER TABLE `testcase_keywords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `testcase_platforms`
--

DROP TABLE IF EXISTS `testcase_platforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `testcase_platforms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `testcase_id` int(10) unsigned NOT NULL DEFAULT 0,
  `tcversion_id` int(10) unsigned NOT NULL DEFAULT 0,
  `platform_id` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx01_testcase_platform` (`testcase_id`,`tcversion_id`,`platform_id`),
  KEY `idx02_testcase_platform` (`tcversion_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `testcase_platforms`
--

LOCK TABLES `testcase_platforms` WRITE;
/*!40000 ALTER TABLE `testcase_platforms` DISABLE KEYS */;
/*!40000 ALTER TABLE `testcase_platforms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `testcase_relations`
--

DROP TABLE IF EXISTS `testcase_relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `testcase_relations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `source_id` int(10) unsigned NOT NULL,
  `destination_id` int(10) unsigned NOT NULL,
  `link_status` tinyint(1) NOT NULL DEFAULT 1,
  `relation_type` smallint(5) unsigned NOT NULL DEFAULT 1,
  `author_id` int(10) unsigned DEFAULT NULL,
  `creation_ts` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `testcase_relations`
--

LOCK TABLES `testcase_relations` WRITE;
/*!40000 ALTER TABLE `testcase_relations` DISABLE KEYS */;
/*!40000 ALTER TABLE `testcase_relations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `testcase_script_links`
--

DROP TABLE IF EXISTS `testcase_script_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `testcase_script_links` (
  `tcversion_id` int(10) unsigned NOT NULL DEFAULT 0,
  `project_key` varchar(64) NOT NULL,
  `repository_name` varchar(64) NOT NULL,
  `code_path` varchar(255) NOT NULL,
  `branch_name` varchar(64) DEFAULT NULL,
  `commit_id` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`tcversion_id`,`project_key`,`repository_name`,`code_path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `testcase_script_links`
--

LOCK TABLES `testcase_script_links` WRITE;
/*!40000 ALTER TABLE `testcase_script_links` DISABLE KEYS */;
/*!40000 ALTER TABLE `testcase_script_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `testplan_platforms`
--

DROP TABLE IF EXISTS `testplan_platforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `testplan_platforms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `testplan_id` int(10) unsigned NOT NULL,
  `platform_id` int(10) unsigned NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_testplan_platforms` (`testplan_id`,`platform_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Connects a testplan with platforms';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `testplan_platforms`
--

LOCK TABLES `testplan_platforms` WRITE;
/*!40000 ALTER TABLE `testplan_platforms` DISABLE KEYS */;
/*!40000 ALTER TABLE `testplan_platforms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `testplan_tcversions`
--

DROP TABLE IF EXISTS `testplan_tcversions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `testplan_tcversions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `testplan_id` int(10) unsigned NOT NULL DEFAULT 0,
  `tcversion_id` int(10) unsigned NOT NULL DEFAULT 0,
  `node_order` int(10) unsigned NOT NULL DEFAULT 1,
  `urgency` smallint(5) NOT NULL DEFAULT 2,
  `platform_id` int(10) unsigned NOT NULL DEFAULT 0,
  `author_id` int(10) unsigned DEFAULT NULL,
  `creation_ts` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `testplan_tcversions_tplan_tcversion` (`testplan_id`,`tcversion_id`,`platform_id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `testplan_tcversions`
--

LOCK TABLES `testplan_tcversions` WRITE;
/*!40000 ALTER TABLE `testplan_tcversions` DISABLE KEYS */;
INSERT INTO `testplan_tcversions` VALUES (1,266,65,1,2,0,1,'2026-10-26 15:39:04'),(2,266,71,1,2,0,1,'2026-10-26 15:39:04'),(3,266,75,1,2,0,1,'2026-10-26 15:39:04'),(4,266,79,1,2,0,1,'2026-10-26 15:39:04'),(5,266,82,1,2,0,1,'2026-10-26 15:39:04'),(6,266,86,1,2,0,1,'2026-10-26 15:39:04'),(7,266,89,1,2,0,1,'2026-10-26 15:39:05'),(8,266,93,1,2,0,1,'2026-10-26 15:39:05'),(9,266,99,1,2,0,1,'2026-10-26 15:39:05'),(10,266,105,1,2,0,1,'2026-10-26 15:39:05'),(11,266,110,1,2,0,1,'2026-10-26 15:39:05'),(12,266,115,1,2,0,1,'2026-10-26 15:39:05'),(13,266,122,1,2,0,1,'2026-10-26 15:39:05'),(14,266,127,1,2,0,1,'2026-10-26 15:39:05'),(15,266,131,1,2,0,1,'2026-10-26 15:39:06'),(16,266,136,1,2,0,1,'2026-10-26 15:39:06'),(17,266,141,1,2,0,1,'2026-10-26 15:39:06'),(18,266,148,1,2,0,1,'2026-10-26 15:39:06'),(19,266,154,1,2,0,1,'2026-10-26 15:39:06'),(20,266,159,1,2,0,1,'2026-10-26 15:39:06'),(21,266,164,1,2,0,1,'2026-10-26 15:39:06'),(22,266,168,1,2,0,1,'2026-10-26 15:39:06'),(23,266,173,1,2,0,1,'2026-10-26 15:39:07'),(24,266,177,1,2,0,1,'2026-10-26 15:39:07'),(25,266,181,1,2,0,1,'2026-10-26 15:39:07'),(26,266,185,1,2,0,1,'2026-10-26 15:39:07'),(27,266,189,1,2,0,1,'2026-10-26 15:39:07'),(28,266,196,1,2,0,1,'2026-10-26 15:39:07'),(29,266,203,1,2,0,1,'2026-10-26 15:39:07'),(30,266,208,1,2,0,1,'2026-10-26 15:39:07'),(31,266,215,1,2,0,1,'2026-10-26 15:39:08'),(32,266,220,1,2,0,1,'2026-10-26 15:39:08'),(33,266,225,1,2,0,1,'2026-10-26 15:39:08'),(34,266,231,1,2,0,1,'2026-10-26 15:39:08'),(35,266,235,1,2,0,1,'2026-10-26 15:39:08'),(36,266,239,1,2,0,1,'2026-10-26 15:39:08'),(37,266,243,1,2,0,1,'2026-10-26 15:39:08'),(38,266,247,1,2,0,1,'2026-10-26 15:39:08'),(39,266,253,1,2,0,1,'2026-10-26 15:39:09'),(40,266,256,1,2,0,1,'2026-10-26 15:39:09'),(41,266,261,1,2,0,1,'2026-10-26 15:39:09');
/*!40000 ALTER TABLE `testplan_tcversions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `testplans`
--

DROP TABLE IF EXISTS `testplans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `testplans` (
  `id` int(10) unsigned NOT NULL,
  `testproject_id` int(10) unsigned NOT NULL DEFAULT 0,
  `notes` text DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `is_open` tinyint(1) NOT NULL DEFAULT 1,
  `is_public` tinyint(1) NOT NULL DEFAULT 1,
  `api_key` varchar(64) NOT NULL DEFAULT '829a2ded3ed0829a2dedd8ab81dfa2c77e8235bc3ed0d8ab81dfa2c77e8235bc',
  PRIMARY KEY (`id`),
  UNIQUE KEY `testplans_api_key` (`api_key`),
  KEY `testplans_testproject_id_active` (`testproject_id`,`active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `testplans`
--

LOCK TABLES `testplans` WRITE;
/*!40000 ALTER TABLE `testplans` DISABLE KEYS */;
INSERT INTO `testplans` VALUES (266,1,'<p>SECJ3343 Project 1 - test case design for UniShare. Each tester adds his own test suites under the project.</p>',1,1,1,'0305ac8755b23d737ade54a71e7cea7371f9b4b4b319765ab0274548a236bf41');
/*!40000 ALTER TABLE `testplans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `testproject_codetracker`
--

DROP TABLE IF EXISTS `testproject_codetracker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `testproject_codetracker` (
  `testproject_id` int(10) unsigned NOT NULL,
  `codetracker_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`testproject_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `testproject_codetracker`
--

LOCK TABLES `testproject_codetracker` WRITE;
/*!40000 ALTER TABLE `testproject_codetracker` DISABLE KEYS */;
/*!40000 ALTER TABLE `testproject_codetracker` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `testproject_issuetracker`
--

DROP TABLE IF EXISTS `testproject_issuetracker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `testproject_issuetracker` (
  `testproject_id` int(10) unsigned NOT NULL,
  `issuetracker_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`testproject_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `testproject_issuetracker`
--

LOCK TABLES `testproject_issuetracker` WRITE;
/*!40000 ALTER TABLE `testproject_issuetracker` DISABLE KEYS */;
/*!40000 ALTER TABLE `testproject_issuetracker` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `testproject_reqmgrsystem`
--

DROP TABLE IF EXISTS `testproject_reqmgrsystem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `testproject_reqmgrsystem` (
  `testproject_id` int(10) unsigned NOT NULL,
  `reqmgrsystem_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`testproject_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `testproject_reqmgrsystem`
--

LOCK TABLES `testproject_reqmgrsystem` WRITE;
/*!40000 ALTER TABLE `testproject_reqmgrsystem` DISABLE KEYS */;
/*!40000 ALTER TABLE `testproject_reqmgrsystem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `testprojects`
--

DROP TABLE IF EXISTS `testprojects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `testprojects` (
  `id` int(10) unsigned NOT NULL,
  `notes` text DEFAULT NULL,
  `color` varchar(12) NOT NULL DEFAULT '#9BD',
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `option_reqs` tinyint(1) NOT NULL DEFAULT 0,
  `option_priority` tinyint(1) NOT NULL DEFAULT 0,
  `option_automation` tinyint(1) NOT NULL DEFAULT 0,
  `options` text DEFAULT NULL,
  `prefix` varchar(16) NOT NULL,
  `tc_counter` int(10) unsigned NOT NULL DEFAULT 0,
  `is_public` tinyint(1) NOT NULL DEFAULT 1,
  `issue_tracker_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `code_tracker_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `reqmgr_integration_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `api_key` varchar(64) NOT NULL DEFAULT '0d8ab81dfa2c77e8235bc829a2ded3edfa2c78235bc829a27eded3ed0d8ab81d',
  PRIMARY KEY (`id`),
  UNIQUE KEY `testprojects_prefix` (`prefix`),
  UNIQUE KEY `testprojects_api_key` (`api_key`),
  KEY `testprojects_id_active` (`id`,`active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `testprojects`
--

LOCK TABLES `testprojects` WRITE;
/*!40000 ALTER TABLE `testprojects` DISABLE KEYS */;
INSERT INTO `testprojects` VALUES (1,'<p>UniShare - university course sharing platform (Next.js / tRPC / Prisma). Group project for SECJ3343 Project 1 (Aland, Karoz, Parwar, Rawa). Source: github.com/Seganation/unishare</p>','',1,0,0,0,'O:8:\"stdClass\":4:{s:19:\"requirementsEnabled\";i:1;s:19:\"testPriorityEnabled\";i:1;s:17:\"automationEnabled\";i:1;s:16:\"inventoryEnabled\";i:0;}','US',41,1,0,0,0,'fbf3c33cee15f9e03a7af7711c2ed20d552ae504963c10c02efe27572c955afb');
/*!40000 ALTER TABLE `testprojects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `testsuites`
--

DROP TABLE IF EXISTS `testsuites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `testsuites` (
  `id` int(10) unsigned NOT NULL,
  `details` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `testsuites`
--

LOCK TABLES `testsuites` WRITE;
/*!40000 ALTER TABLE `testsuites` DISABLE KEYS */;
INSERT INTO `testsuites` VALUES (62,'<p><b>Tester:</b> Rawa Dara<br/><b>Software under test:</b> UniShare (github.com/Seganation/unishare)<br/><b>Test basis:</b> UniShare_Iteration_4.md use cases UC-S4-001, UC-S4-003, UC-S4-004 and the tRPC routers course.ts, resource.ts, article.ts, notification.ts.<br/><b>Techniques:</b> Equivalence Partitioning (EP), Boundary Value Analysis (BVA), Decision Table (DT), State Transition (ST), Use Case / scenario testing (UC), Error Guessing (EG).</p><p><b>Common test data</b><br/>Student A - Sarah Ahmed (sarah@student.utm.my), course owner, APPROVED, Faculty of Computing<br/>Student B - John Doe (john@student.utm.my), APPROVED, Faculty of Computing (same faculty as A)<br/>Student C - Michael Chen (michael@student.utm.my), APPROVED, Faculty of Engineering (different faculty)<br/>Student D - Alice Wong (alice@student.utm.my), role PENDING (not approved)<br/>Seed data: prisma/seed.ts (all seeded passwords documented there).<br/>Course: \"SECJ3343 Software Quality Assurance\" created by Student A with one resource card \"Lecture Slides\" (file uploads allowed) holding file week1.pdf.</p>'),(63,'<p>Owner invites students to a course. Techniques: EP, DT, EG.</p>'),(97,'<p>Invitee accepts / declines. Techniques: ST (PENDING -&gt; ACCEPTED/REJECTED), DT.</p>'),(113,'<p>Decision table: role {Owner, Contributor, Viewer} x action {view, download, add, upload, delete resource, delete course}.</p>'),(134,'<p>My Articles &gt; New Article / Edit. Techniques: BVA on title (1..200) and excerpt (0..500), EP on cover URL.</p>'),(171,'<p>State transition: DRAFT -&gt; PUBLISHED -&gt; ARCHIVED, delete from any state.</p>'),(194,'<p>/articles and /articles/[slug]. Techniques: EP, BVA on paging, DT on access.</p>'),(223,'<p>Bell icon in the header. Techniques: BVA on badge (0, 1, 9, 10), ST (unread -&gt; read).</p>'),(251,'<p>Settings &gt; Notification Preferences. Techniques: EP, BVA (5..30 minutes), DT (channel x type).</p>');
/*!40000 ALTER TABLE `testsuites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `text_templates`
--

DROP TABLE IF EXISTS `text_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `text_templates` (
  `id` int(10) unsigned NOT NULL,
  `type` smallint(5) unsigned NOT NULL,
  `title` varchar(100) NOT NULL,
  `template_data` text DEFAULT NULL,
  `author_id` int(10) unsigned DEFAULT NULL,
  `creation_ts` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_public` tinyint(1) NOT NULL DEFAULT 0,
  UNIQUE KEY `idx_text_templates` (`type`,`title`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Global Project Templates';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `text_templates`
--

LOCK TABLES `text_templates` WRITE;
/*!40000 ALTER TABLE `text_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `text_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `transactions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_point` varchar(45) NOT NULL DEFAULT '',
  `start_time` int(10) unsigned NOT NULL DEFAULT 0,
  `end_time` int(10) unsigned NOT NULL DEFAULT 0,
  `user_id` int(10) unsigned NOT NULL DEFAULT 0,
  `session_id` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactions`
--

LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
INSERT INTO `transactions` VALUES (1,'/lib/api/xmlrpc/v1/xmlrpc.php',1793029139,1793029139,1,''),(2,'/lib/api/xmlrpc/v1/xmlrpc.php',1793029139,1793029139,1,''),(3,'/login.php',1793029139,1793029139,1,'5baff009de7e3765c47ccc0ffb84f721'),(4,'/lib/requirements/reqImport.php',1793029139,1793029139,1,'5baff009de7e3765c47ccc0ffb84f721'),(5,'/lib/api/xmlrpc/v1/xmlrpc.php',1793029140,1793029140,1,''),(6,'/lib/api/xmlrpc/v1/xmlrpc.php',1793029140,1793029140,1,''),(7,'/lib/api/xmlrpc/v1/xmlrpc.php',1793029140,1793029140,1,''),(8,'/lib/api/xmlrpc/v1/xmlrpc.php',1793029140,1793029140,1,''),(9,'/lib/api/xmlrpc/v1/xmlrpc.php',1793029140,1793029140,1,''),(10,'/lib/api/xmlrpc/v1/xmlrpc.php',1793029140,1793029140,1,''),(11,'/lib/api/xmlrpc/v1/xmlrpc.php',1793029140,1793029140,1,''),(12,'/lib/api/xmlrpc/v1/xmlrpc.php',1793029140,1793029140,1,''),(13,'/lib/api/xmlrpc/v1/xmlrpc.php',1793029141,1793029141,1,''),(14,'/lib/api/xmlrpc/v1/xmlrpc.php',1793029141,1793029141,1,''),(15,'/lib/api/xmlrpc/v1/xmlrpc.php',1793029141,1793029141,1,''),(16,'/lib/api/xmlrpc/v1/xmlrpc.php',1793029141,1793029141,1,''),(17,'/lib/api/xmlrpc/v1/xmlrpc.php',1793029141,1793029141,1,''),(18,'/lib/api/xmlrpc/v1/xmlrpc.php',1793029141,1793029141,1,''),(19,'/lib/api/xmlrpc/v1/xmlrpc.php',1793029141,1793029141,1,''),(20,'/lib/api/xmlrpc/v1/xmlrpc.php',1793029141,1793029141,1,''),(21,'/lib/api/xmlrpc/v1/xmlrpc.php',1793029141,1793029141,1,''),(22,'/lib/api/xmlrpc/v1/xmlrpc.php',1793029141,1793029141,1,''),(23,'/lib/api/xmlrpc/v1/xmlrpc.php',1793029142,1793029142,1,''),(24,'/lib/api/xmlrpc/v1/xmlrpc.php',1793029142,1793029142,1,''),(25,'/lib/api/xmlrpc/v1/xmlrpc.php',1793029142,1793029142,1,''),(26,'/lib/api/xmlrpc/v1/xmlrpc.php',1793029142,1793029142,1,''),(27,'/lib/api/xmlrpc/v1/xmlrpc.php',1793029142,1793029142,1,''),(28,'/lib/api/xmlrpc/v1/xmlrpc.php',1793029142,1793029142,1,''),(29,'/lib/api/xmlrpc/v1/xmlrpc.php',1793029142,1793029142,1,''),(30,'/lib/api/xmlrpc/v1/xmlrpc.php',1793029142,1793029142,1,''),(31,'/lib/api/xmlrpc/v1/xmlrpc.php',1793029142,1793029142,1,''),(32,'/lib/api/xmlrpc/v1/xmlrpc.php',1793029142,1793029142,1,''),(33,'/lib/api/xmlrpc/v1/xmlrpc.php',1793029142,1793029142,1,''),(34,'/lib/api/xmlrpc/v1/xmlrpc.php',1793029143,1793029143,1,''),(35,'/lib/api/xmlrpc/v1/xmlrpc.php',1793029143,1793029143,1,''),(36,'/lib/api/xmlrpc/v1/xmlrpc.php',1793029143,1793029143,1,''),(37,'/lib/api/xmlrpc/v1/xmlrpc.php',1793029143,1793029143,1,''),(38,'/lib/api/xmlrpc/v1/xmlrpc.php',1793029143,1793029143,1,''),(39,'/lib/api/xmlrpc/v1/xmlrpc.php',1793029143,1793029143,1,''),(40,'/lib/api/xmlrpc/v1/xmlrpc.php',1793029143,1793029143,1,''),(41,'/lib/api/xmlrpc/v1/xmlrpc.php',1793029143,1793029143,1,''),(42,'/lib/api/xmlrpc/v1/xmlrpc.php',1793029143,1793029143,1,''),(43,'/lib/api/xmlrpc/v1/xmlrpc.php',1793029143,1793029143,1,''),(44,'/lib/api/xmlrpc/v1/xmlrpc.php',1793029143,1793029143,1,''),(45,'/lib/api/xmlrpc/v1/xmlrpc.php',1793029144,1793029144,1,''),(46,'/login.php',1793029188,1793029188,2,'662bc966e50b7081b3f6ae9ffcfd4c2f'),(47,'/lib/results/printDocument.php',1793029188,1793029188,2,'662bc966e50b7081b3f6ae9ffcfd4c2f'),(48,'/lib/results/printDocument.php',1793029188,1793029188,2,'662bc966e50b7081b3f6ae9ffcfd4c2f'),(49,'/lib/results/printDocument.php',1793029203,1793029203,2,'662bc966e50b7081b3f6ae9ffcfd4c2f'),(50,'/lib/results/printDocument.php',1793029203,1793029203,2,'662bc966e50b7081b3f6ae9ffcfd4c2f'),(51,'/lib/results/printDocument.php',1793029246,1793029246,2,'662bc966e50b7081b3f6ae9ffcfd4c2f'),(52,'/lib/results/printDocument.php',1793029249,1793029249,2,'662bc966e50b7081b3f6ae9ffcfd4c2f'),(53,'/lib/testcases/tcExport.php',1793029264,1793029264,2,'662bc966e50b7081b3f6ae9ffcfd4c2f'),(54,'/lib/api/xmlrpc/v1/xmlrpc.php',1793029475,1793029475,1,'');
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `tsuites_tree_depth_2`
--

DROP TABLE IF EXISTS `tsuites_tree_depth_2`;
/*!50001 DROP VIEW IF EXISTS `tsuites_tree_depth_2`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `tsuites_tree_depth_2` AS SELECT
 NULL AS `prefix`,
 NULL AS `testproject_name`,
 NULL AS `level1_name`,
 NULL AS `level2_name`,
 NULL AS `testproject_id`,
 NULL AS `level1_id`,
 NULL AS `level2_id` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `user_assignments`
--

DROP TABLE IF EXISTS `user_assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_assignments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` int(10) unsigned NOT NULL DEFAULT 1,
  `feature_id` int(10) unsigned NOT NULL DEFAULT 0,
  `user_id` int(10) unsigned DEFAULT 0,
  `build_id` int(10) unsigned DEFAULT 0,
  `deadline_ts` datetime DEFAULT NULL,
  `assigner_id` int(10) unsigned DEFAULT 0,
  `creation_ts` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` int(10) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `user_assignments_feature_id` (`feature_id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_assignments`
--

LOCK TABLES `user_assignments` WRITE;
/*!40000 ALTER TABLE `user_assignments` DISABLE KEYS */;
INSERT INTO `user_assignments` VALUES (1,1,1,2,1,NULL,1,'2026-10-26 15:39:04',1),(2,1,2,2,1,NULL,1,'2026-10-26 15:39:04',1),(3,1,3,2,1,NULL,1,'2026-10-26 15:39:04',1),(4,1,4,2,1,NULL,1,'2026-10-26 15:39:04',1),(5,1,5,2,1,NULL,1,'2026-10-26 15:39:04',1),(6,1,6,2,1,NULL,1,'2026-10-26 15:39:04',1),(7,1,7,2,1,NULL,1,'2026-10-26 15:39:05',1),(8,1,8,2,1,NULL,1,'2026-10-26 15:39:05',1),(9,1,9,2,1,NULL,1,'2026-10-26 15:39:05',1),(10,1,10,2,1,NULL,1,'2026-10-26 15:39:05',1),(11,1,11,2,1,NULL,1,'2026-10-26 15:39:05',1),(12,1,12,2,1,NULL,1,'2026-10-26 15:39:05',1),(13,1,13,2,1,NULL,1,'2026-10-26 15:39:05',1),(14,1,14,2,1,NULL,1,'2026-10-26 15:39:05',1),(15,1,15,2,1,NULL,1,'2026-10-26 15:39:06',1),(16,1,16,2,1,NULL,1,'2026-10-26 15:39:06',1),(17,1,17,2,1,NULL,1,'2026-10-26 15:39:06',1),(18,1,18,2,1,NULL,1,'2026-10-26 15:39:06',1),(19,1,19,2,1,NULL,1,'2026-10-26 15:39:06',1),(20,1,20,2,1,NULL,1,'2026-10-26 15:39:06',1),(21,1,21,2,1,NULL,1,'2026-10-26 15:39:06',1),(22,1,22,2,1,NULL,1,'2026-10-26 15:39:06',1),(23,1,23,2,1,NULL,1,'2026-10-26 15:39:07',1),(24,1,24,2,1,NULL,1,'2026-10-26 15:39:07',1),(25,1,25,2,1,NULL,1,'2026-10-26 15:39:07',1),(26,1,26,2,1,NULL,1,'2026-10-26 15:39:07',1),(27,1,27,2,1,NULL,1,'2026-10-26 15:39:07',1),(28,1,28,2,1,NULL,1,'2026-10-26 15:39:07',1),(29,1,29,2,1,NULL,1,'2026-10-26 15:39:07',1),(30,1,30,2,1,NULL,1,'2026-10-26 15:39:07',1),(31,1,31,2,1,NULL,1,'2026-10-26 15:39:08',1),(32,1,32,2,1,NULL,1,'2026-10-26 15:39:08',1),(33,1,33,2,1,NULL,1,'2026-10-26 15:39:08',1),(34,1,34,2,1,NULL,1,'2026-10-26 15:39:08',1),(35,1,35,2,1,NULL,1,'2026-10-26 15:39:08',1),(36,1,36,2,1,NULL,1,'2026-10-26 15:39:08',1),(37,1,37,2,1,NULL,1,'2026-10-26 15:39:08',1),(38,1,38,2,1,NULL,1,'2026-10-26 15:39:08',1),(39,1,39,2,1,NULL,1,'2026-10-26 15:39:09',1),(40,1,40,2,1,NULL,1,'2026-10-26 15:39:09',1),(41,1,41,2,1,NULL,1,'2026-10-26 15:39:09',1);
/*!40000 ALTER TABLE `user_assignments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_group`
--

DROP TABLE IF EXISTS `user_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_group` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_user_group` (`title`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_group`
--

LOCK TABLES `user_group` WRITE;
/*!40000 ALTER TABLE `user_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_group_assign`
--

DROP TABLE IF EXISTS `user_group_assign`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_group_assign` (
  `usergroup_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  UNIQUE KEY `idx_user_group_assign` (`usergroup_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_group_assign`
--

LOCK TABLES `user_group_assign` WRITE;
/*!40000 ALTER TABLE `user_group_assign` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_group_assign` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_testplan_roles`
--

DROP TABLE IF EXISTS `user_testplan_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_testplan_roles` (
  `user_id` int(10) NOT NULL DEFAULT 0,
  `testplan_id` int(10) NOT NULL DEFAULT 0,
  `role_id` int(10) NOT NULL DEFAULT 0,
  PRIMARY KEY (`user_id`,`testplan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_testplan_roles`
--

LOCK TABLES `user_testplan_roles` WRITE;
/*!40000 ALTER TABLE `user_testplan_roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_testplan_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_testproject_roles`
--

DROP TABLE IF EXISTS `user_testproject_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_testproject_roles` (
  `user_id` int(10) NOT NULL DEFAULT 0,
  `testproject_id` int(10) NOT NULL DEFAULT 0,
  `role_id` int(10) NOT NULL DEFAULT 0,
  PRIMARY KEY (`user_id`,`testproject_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_testproject_roles`
--

LOCK TABLES `user_testproject_roles` WRITE;
/*!40000 ALTER TABLE `user_testproject_roles` DISABLE KEYS */;
INSERT INTO `user_testproject_roles` VALUES (2,1,6),(3,1,6),(4,1,6),(5,1,6);
/*!40000 ALTER TABLE `user_testproject_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `login` varchar(100) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `role_id` int(10) unsigned NOT NULL DEFAULT 0,
  `email` varchar(100) NOT NULL DEFAULT '',
  `first` varchar(50) NOT NULL DEFAULT '',
  `last` varchar(50) NOT NULL DEFAULT '',
  `locale` varchar(10) NOT NULL DEFAULT 'en_GB',
  `default_testproject_id` int(10) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `script_key` varchar(32) DEFAULT NULL,
  `cookie_string` varchar(64) NOT NULL DEFAULT '',
  `auth_method` varchar(10) DEFAULT '',
  `creation_ts` timestamp NOT NULL DEFAULT current_timestamp(),
  `expiration_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_login` (`login`),
  UNIQUE KEY `users_cookie_string` (`cookie_string`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='User information';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','$2y$10$yrU7pVBatSqj9BPovNDxEONz1XcsfdbiW0eWuAKai0QBGABReUHZu',8,'','Testlink','Administrator','en_GB',1,1,'7bea5a09348d5cba56ab96d5c5af2a06','e25e1ca5dd4f0d8f732a96a15bc7dcdd89bfa609e0fb05794c93d1aebef245e0','','2026-10-26 15:26:05',NULL),(2,'rawa','1d2b71d4f3a855a68dba6f2e2dacb334',6,'rawa@example.test','Rawa','Dara','en_GB',1,1,NULL,'32eb622fa6ddee3a65d625f6bdba7ab143d47fae8f50bf2db95397801adc8545','DB','2026-10-26 15:31:17',NULL),(3,'aland','0c3b2be22d7bbabc38403eff5a5f2a74',6,'aland@example.test','Aland','','en_GB',1,1,NULL,'eb02504f1f6e5d2abb75df43caade614','','2026-10-26 16:50:16',NULL),(4,'karoz','c0e1e0dd50322c44becc5b4827445b3c',6,'karoz@example.test','Karoz','','en_GB',1,1,NULL,'fa33af7809a1bbb40808ceab9726217c','','2026-10-26 16:50:16',NULL),(5,'parwar','5aa1a19abf716ee7b6e76df6d5d4ae0f',6,'parwar@example.test','Parwar','','en_GB',1,1,NULL,'8fd571f796e7f1ae8d4fee1a20e6c7c4','','2026-10-26 16:50:16',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'testlink'
--
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP FUNCTION IF EXISTS `UDFStripHTMLTags` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb3 */ ;
/*!50003 SET character_set_results = utf8mb3 */ ;
/*!50003 SET collation_connection  = utf8mb3_general_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `UDFStripHTMLTags`(Dirty TEXT) RETURNS text CHARSET utf8mb3 COLLATE utf8mb3_general_ci
BEGIN
DECLARE iStart, iEnd, iLength int;
   WHILE Locate( '<', Dirty ) > 0 And Locate( '>', Dirty, Locate( '<', Dirty )) > 0 DO
      BEGIN
        SET iStart = Locate( '<', Dirty ), iEnd = Locate( '>', Dirty, Locate('<', Dirty ));
        SET iLength = ( iEnd - iStart) + 1;
        IF iLength > 0 THEN
          BEGIN
            SET Dirty = Insert( Dirty, iStart, iLength, '');
          END;
        END IF;
      END;
    END WHILE;
RETURN Dirty;
END
;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Final view structure for view `exec_by_date_time`
--

/*!50001 DROP VIEW IF EXISTS `exec_by_date_time`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `exec_by_date_time` AS (select `NHTPL`.`name` AS `testplan_name`,date_format(`E`.`execution_ts`,'%Y-%m-%d') AS `yyyy_mm_dd`,date_format(`E`.`execution_ts`,'%Y-%m') AS `yyyy_mm`,date_format(`E`.`execution_ts`,'%H') AS `hh`,date_format(`E`.`execution_ts`,'%k') AS `hour`,`E`.`id` AS `id`,`E`.`build_id` AS `build_id`,`E`.`tester_id` AS `tester_id`,`E`.`execution_ts` AS `execution_ts`,`E`.`status` AS `status`,`E`.`testplan_id` AS `testplan_id`,`E`.`tcversion_id` AS `tcversion_id`,`E`.`tcversion_number` AS `tcversion_number`,`E`.`platform_id` AS `platform_id`,`E`.`execution_type` AS `execution_type`,`E`.`execution_duration` AS `execution_duration`,`E`.`notes` AS `notes` from ((`executions` `E` join `testplans` `TPL` on(`TPL`.`id` = `E`.`testplan_id`)) join `nodes_hierarchy` `NHTPL` on(`NHTPL`.`id` = `TPL`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `latest_exec_by_context`
--

/*!50001 DROP VIEW IF EXISTS `latest_exec_by_context`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `latest_exec_by_context` AS select `executions`.`tcversion_id` AS `tcversion_id`,`executions`.`testplan_id` AS `testplan_id`,`executions`.`build_id` AS `build_id`,`executions`.`platform_id` AS `platform_id`,max(`executions`.`id`) AS `id` from `executions` group by `executions`.`tcversion_id`,`executions`.`testplan_id`,`executions`.`build_id`,`executions`.`platform_id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `latest_exec_by_testplan`
--

/*!50001 DROP VIEW IF EXISTS `latest_exec_by_testplan`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `latest_exec_by_testplan` AS select `executions`.`tcversion_id` AS `tcversion_id`,`executions`.`testplan_id` AS `testplan_id`,max(`executions`.`id`) AS `id` from `executions` group by `executions`.`tcversion_id`,`executions`.`testplan_id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `latest_exec_by_testplan_plat`
--

/*!50001 DROP VIEW IF EXISTS `latest_exec_by_testplan_plat`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `latest_exec_by_testplan_plat` AS select `executions`.`tcversion_id` AS `tcversion_id`,`executions`.`testplan_id` AS `testplan_id`,`executions`.`platform_id` AS `platform_id`,max(`executions`.`id`) AS `id` from `executions` group by `executions`.`tcversion_id`,`executions`.`testplan_id`,`executions`.`platform_id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `latest_req_version`
--

/*!50001 DROP VIEW IF EXISTS `latest_req_version`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `latest_req_version` AS select `RQ`.`id` AS `req_id`,max(`RQV`.`version`) AS `version` from ((`nodes_hierarchy` `NHRQV` join `requirements` `RQ` on(`RQ`.`id` = `NHRQV`.`parent_id`)) join `req_versions` `RQV` on(`RQV`.`id` = `NHRQV`.`id`)) group by `RQ`.`id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `latest_req_version_id`
--

/*!50001 DROP VIEW IF EXISTS `latest_req_version_id`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `latest_req_version_id` AS select `LRQVN`.`req_id` AS `req_id`,`LRQVN`.`version` AS `version`,`REQV`.`id` AS `req_version_id` from ((`latest_req_version` `LRQVN` join `nodes_hierarchy` `NHRQV` on(`NHRQV`.`parent_id` = `LRQVN`.`req_id`)) join `req_versions` `REQV` on(`REQV`.`id` = `NHRQV`.`id` and `REQV`.`version` = `LRQVN`.`version`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `latest_rspec_revision`
--

/*!50001 DROP VIEW IF EXISTS `latest_rspec_revision`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `latest_rspec_revision` AS select `RSR`.`parent_id` AS `req_spec_id`,`RS`.`testproject_id` AS `testproject_id`,max(`RSR`.`revision`) AS `revision` from (`req_specs_revisions` `RSR` join `req_specs` `RS` on(`RS`.`id` = `RSR`.`parent_id`)) group by `RSR`.`parent_id`,`RS`.`testproject_id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `latest_tcase_version_id`
--

/*!50001 DROP VIEW IF EXISTS `latest_tcase_version_id`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `latest_tcase_version_id` AS select `LTCVN`.`testcase_id` AS `testcase_id`,`LTCVN`.`version` AS `version`,`TCV`.`id` AS `tcversion_id` from ((`latest_tcase_version_number` `LTCVN` join `nodes_hierarchy` `NHTCV` on(`NHTCV`.`parent_id` = `LTCVN`.`testcase_id`)) join `tcversions` `TCV` on(`TCV`.`id` = `NHTCV`.`id` and `TCV`.`version` = `LTCVN`.`version`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `latest_tcase_version_number`
--

/*!50001 DROP VIEW IF EXISTS `latest_tcase_version_number`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `latest_tcase_version_number` AS select `NH_TC`.`id` AS `testcase_id`,max(`TCV`.`version`) AS `version` from ((`nodes_hierarchy` `NH_TC` join `nodes_hierarchy` `NH_TCV` on(`NH_TCV`.`parent_id` = `NH_TC`.`id`)) join `tcversions` `TCV` on(`NH_TCV`.`id` = `TCV`.`id`)) group by `NH_TC`.`id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `tcversions_without_keywords`
--

/*!50001 DROP VIEW IF EXISTS `tcversions_without_keywords`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `tcversions_without_keywords` AS select `NHTCV`.`parent_id` AS `testcase_id`,`NHTCV`.`id` AS `id` from `nodes_hierarchy` `NHTCV` where `NHTCV`.`node_type_id` = 4 and !exists(select 1 from `testcase_keywords` `TCK` where `TCK`.`tcversion_id` = `NHTCV`.`id` limit 1) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `tcversions_without_platforms`
--

/*!50001 DROP VIEW IF EXISTS `tcversions_without_platforms`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `tcversions_without_platforms` AS select `NHTCV`.`parent_id` AS `testcase_id`,`NHTCV`.`id` AS `id` from `nodes_hierarchy` `NHTCV` where `NHTCV`.`node_type_id` = 4 and !exists(select 1 from `testcase_platforms` `TCPL` where `TCPL`.`tcversion_id` = `NHTCV`.`id` limit 1) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `tsuites_tree_depth_2`
--

/*!50001 DROP VIEW IF EXISTS `tsuites_tree_depth_2`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `tsuites_tree_depth_2` AS select `TPRJ`.`prefix` AS `prefix`,`NHTPRJ`.`name` AS `testproject_name`,`NHTS_L1`.`name` AS `level1_name`,`NHTS_L2`.`name` AS `level2_name`,`NHTPRJ`.`id` AS `testproject_id`,`NHTS_L1`.`id` AS `level1_id`,`NHTS_L2`.`id` AS `level2_id` from (((`testprojects` `TPRJ` join `nodes_hierarchy` `NHTPRJ` on(`TPRJ`.`id` = `NHTPRJ`.`id`)) left join `nodes_hierarchy` `NHTS_L1` on(`NHTS_L1`.`parent_id` = `NHTPRJ`.`id`)) left join `nodes_hierarchy` `NHTS_L2` on(`NHTS_L2`.`parent_id` = `NHTS_L1`.`id`)) where `NHTPRJ`.`node_type_id` = 1 and `NHTS_L1`.`node_type_id` = 2 and `NHTS_L2`.`node_type_id` = 2 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-26 16:50:52
